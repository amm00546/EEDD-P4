# Análisis de tablas de dispersión

* *Alberto Moya Mateo*
* *Pablo Lechuga García*

## Tamaño de tabla: xx
| función | máximo de colisiones | supera 10 colisiones | factor de carga | promedio de colisiones |
|---------|:--------------------:|:--------------------:|:---------------:|:----------------------:|
| texto   |        valor         |       valor          |     valor       |                        |
| texto   |        valor         |       valor          |     valor       |                        |
| texto| valor | valor | valor | |


## Tamaño de tabla: yy
| función | máximo de colisiones | supera 10 colisiones | factor de carga | promedio de colisiones |
|---------|:--------------------:|:--------------------:|:---------------:|:----------------------:|
| texto   |        valor         |       valor          |     valor       |                        |
| texto   |        valor         |       valor          |     valor       |                        |
| texto| valor | valor | valor | |

## Justificación de la configuración elegida
Hemos optado por ...


## Comparación de tiempos dados en milisegundos
Tiempo en realizar las búsquedas en la Tabla Hash:
Tiempo en realizar las búsquedas en la Lista: