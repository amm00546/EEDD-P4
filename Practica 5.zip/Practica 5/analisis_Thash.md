# Análisis de tablas de dispersión

* *Alberto Moya Mateo*
* *Pablo Lechuga García*

## Tamaño de tabla: 206879 (λ = 0.65)
| función | máximo de colisiones | supera 10 colisiones | factor de carga | promedio de colisiones |
|---------|:--------------------:|:--------------------:|:---------------:|:----------------------:|
| 1.hash1<br/>(cuadratica)   |          95          |         6330         |    0.649839     |        1.84124         |
| 2.hash2<br/>(doble)     |          18          |         103          |      0.649839      |        0.59986         |
| 3.hash3 <br/>(inventada)|          19          |          80          |       0.649839      |        0.574808        |


## Tamaño de tabla: 197711 (λ = 0.68)
| función                  | máximo de colisiones | supera 10 colisiones | factor de carga | promedio de colisiones |
|--------------------------|:--------------------:|:--------------------:|:---------------:|:----------------------:|
| 1.hash1<br/>(cuadratica) |         111          |        10847         |      0.679972     |        3.79932         |
| 2.hash2<br/>(doble)      |          40          |         167          |      0.679972      |        0.67292         |
| 3.hash3 <br/>(inventada) |          27          |         141          |    0.679972     |        0.648388        |

## Justificación de la configuración elegida
Hemos optado por por λ=0.65 con la dispersión doble hash3.

1. La cuadrática se descarta. Solo elimina el agrupamiento primario, es decir, todas las claves son el mismo x mod T(tamaño) siguen exactamente la misma secuencia.
Además tiene el promedio mas alto y miles de inserciones con mas de 10 colisiones
2. Ahora, comparando los 2 hash de dispersión doble, observamos que en la hash2 solo depende de la parte alta de la clave(x/T) y la hash3 suma tambien la parte baja (x mod Q), pero usando el factor 7 obtenemoslos saltos de forma consecutiva
La hash3 al estar con λ=0.65 reduce el promedio en un 4.2%, el total de colisiones a 77276 y los casos con mas de 10 colisiones a un 22%.

## Comparación de tiempos dados en milisegundos
Tiempo en realizar las búsquedas en la Tabla Hash: 0.3797 ms

Tiempo en realizar las búsquedas en la Lista: 8149.23 ms 