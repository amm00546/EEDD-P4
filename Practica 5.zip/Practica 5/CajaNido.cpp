//
// Created by palega on 18/11/2026.
//

#include "CajaNido.h"

CajaNido::CajaNido(): coord(0,0), itsTree(nullptr){

}

CajaNido::CajaNido(const std::string &distrito, const std::string &barrio, const std::string &ubicacion, UTM coord):
                    coord(coord), distrito(distrito), barrio(barrio), ubicacion(ubicacion), itsTree(nullptr){

}

CajaNido::CajaNido(const CajaNido &orig): coord(orig.coord), distrito(orig.distrito),
                                            barrio(orig.barrio), ubicacion(orig.ubicacion) {

}

//NUEVOS METODOS
void CajaNido::setArbol(Arbol *a) {
    itsTree = a;
}

Arbol* CajaNido::getArbol() const{
    return itsTree;
}


bool CajaNido::estaEnArbol() const {
    if (itsTree !=nullptr) {
        return true;
    }
    return false;
}


//GETTERS
const UTM& CajaNido::getCoord() {
    return coord;
}

const std::string &CajaNido::getDistrito() {
    return distrito;
}

const std::string &CajaNido::getBarrio() {
    return barrio;
}

const std::string &CajaNido::getUbicacion() {
    return ubicacion;
}


