//
// Created by a_amo on 07/10/2026.
//

#ifndef PRACTICA_3_PARQUE_H
#define PRACTICA_3_PARQUE_H
#include <string>
#include <vector>
#include <set>
#include <map>
#include "Arbol.h"


class Especie;
class Parque {
private:
    int cod_parque;
    std::string nbre_parque;
    std::vector<Arbol*> contains;

public:
    // Constructor por defecto
    Parque();
    // Constructor parametrizado
    Parque(int codigo, const std::string& nParque);
    // Constructor copia
    Parque(const Parque& orig);

    // Getters
    int get_codigo_parque() const;
    const std::string& get_nombre_parque() const;

    // Setters
    void set_codigo_parque(int c);
    void set_nombre_parque(const std::string& n);

    // Operador de asignación
    Parque& operator=(const Parque& orig);

    // Operadores para la ordenación
    bool operator<(const Parque& orig) const;
    bool operator==(const Parque& orig) const;

    // MÉTODOS EN EL UML
    /**
     * @brief metodo que dado un nombre comun, busca por el vector si existe dicho nombre
     * @param ncomun
     * @return true o false
     */
    bool existeNbreCom(const std::string& ncomun) const;

    /**
     * @brief metodo de insercion de los arboles en los parques
     * @param arb
     */
    void insertarArbol(Arbol* arb);

    /**
     * @brief metodo de busqueda por altura del arbol mas alto
     * @return puntero al arbol mas alto
     */
    Arbol* arbolMasAlto() const;

    /**
     * @brief metodo que cuenta las diferentes especies
     * @return el tamaño del set
     */
    int contarEspecies() const;

    /**
     * @brief metodo que cuenta los diferentes tipos de especie
     * @return tamaño del set
     */
    int contarTipos() const;

    /**
     * @brief metodo de busqueda de la especie que mayor frecuencia aparece
     * @return puntero a la especie mas comun
     */
    Especie* especieMasComun() const;
    // Metodo auxiliar para consultar los arboles
    const std::vector<Arbol*>& getArboles() const;


};


#endif //PRACTICA_3_PARQUE_H