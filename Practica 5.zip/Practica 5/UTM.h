//
// Created by palega on 18/11/2026.
//

#ifndef PRACTICA_5_UTM_H
#define PRACTICA_5_UTM_H

#include "CajaNido.h"
#include "Arbol.h"

class UTM {
private:
    double X;
    double Y;
public:
    //CONSTRUCTORES Y DESTRUCTORES
    UTM();
    UTM(double X, double Y);
    //NUEVOS METODOS
    double distancia2(const UTM &otra) const;

    //GETTERS
    double getX() const;
    double getY() const;
};


#endif //PRACTICA_5_UTM_H