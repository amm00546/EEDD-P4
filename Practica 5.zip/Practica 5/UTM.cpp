//
// Created by palega on 18/11/2026.
//

#include "UTM.h"

UTM::UTM(double X, double Y): X(X), Y(Y) {
}

UTM::UTM(): X(0), Y(0){
}

double UTM::getX() const {
    return X;
}

double UTM::getY() const {
    return Y;
}

double UTM::distancia2(const UTM &otra) const {
    double dx = getX() - otra.getX();
    double dy= getY() - otra.getY();
    return dx*dx + dy*dy;
}
