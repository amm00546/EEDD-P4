//
// Created by a_amo on 07/10/2026.
//

#include "ControlParques.h"
#include "LectorCSV.h"
#include <stdexcept>
#include <algorithm>

ControlParques::ControlParques(const std::string& rutaEspecies,
    const std::string& rutaParques, const std::string& rutaArboles, const std::string& rutaCajasNido, float lambda, int tipoHash):
    trees(134438, 0.65, 3) {
    LectorCSV lector;

    if (!lector.cargar(especies, rutaEspecies)) {
        throw std::runtime_error("ControlParques: No se pudo abrir " + rutaEspecies);
    }

    if (!lector.cargarParques(parques, rutaParques)) {
        throw std::runtime_error("ControlParques: No se pudo abrir " + rutaParques);
    }

    // Vector temporal para guardar los punteros a los árboles mientras se cargan
    std::vector<Arbol*> listaArboles;

    bool ok = lector.cargarArboles(rutaArboles, [this, &listaArboles](Arbol& leido, const std::string& codEspecie) {
        unsigned long clave = djb2(leido.getAssetnum().c_str());
        if (!trees.insertar(clave, leido)) {
            return;
        }
        Arbol* a = trees.buscar(clave);
        idArboles.push_back(a->getAssetnum());
        listaArboles.push_back(a);
        a->setEspecie(buscarEspecieCodigo(codEspecie));

        Parque* p = buscarParqueCodigo(a->getNumParque());
        if (p != nullptr) {
            p->insertarArbol(a);
            a->setParque(p);
        }

        if (a->getEspecie() != nullptr) {
            treeName.insert(std::make_pair(a->getNbreComun(), a));
        }
    });

    if (!ok) {
        throw std::runtime_error("ControlParques: no se pudo abrir " + rutaArboles);
    }

    if (!lector.cargarCajasNido(nests, rutaCajasNido)) {
        throw std::runtime_error("ControlParques: no se pudo abrir " + rutaCajasNido);
    }

    // Asociar cada caja nido al árbol más cercano (a menos de 10 metros)
    for (unsigned int i = 0; i < nests.size(); i++) {
        Arbol* masCercano = nullptr;
        double minDist2 = 100.0;
        double cx = nests[i].getCoord().getX();
        double cy = nests[i].getCoord().getY();

        for (unsigned int j = 0; j < listaArboles.size(); j++) {
            Arbol* a = listaArboles[j];
            double dx = a->getCoord().getX() - cx;
            if (dx >= 10.0 || dx <= -10.0) continue;

            double dy = a->getCoord().getY() - cy;
            if (dy >= 10.0 || dy <= -10.0) continue;

            double d2 = dx * dx + dy * dy;
            if (d2 < minDist2) {
                minDist2 = d2;
                masCercano = a;
            }
        }
        nests[i].setArbol(masCercano);
    }
}

/**
 * @brief metodo getter del map de especies
 * @return puntero this a la estrctura especie
 */
std::map<std::string,Especie>& ControlParques::get_especies() {
    return this->especies;
}

/**
 * @brief metodo getter del map de Parques
 * @return puntero this a parques
 */
std::map<int,Parque>& ControlParques::get_parques() {
    return this->parques;
}


/**
 * @brief metodo que cuenta cuantas especies hay por parque
 * @param nComun
 * @return tamaño de la lista
 */
int ControlParques::contarEspecieParque(const std::string& nComun) {
    if (nComun.empty()) {
        throw std::invalid_argument("Nombre comun vacio");

    }
    return listarParquesArbol(nComun).size();
}

/**
 * @brief metodo que asigna a cada especie un parque correspondiente
 * @param e
 * @param p
 */
void ControlParques::asignarEspecieParque(Especie* e, Parque& p) {
    if (e==nullptr) {
        return;
    }
    std::vector<Arbol*> arbolesParque = p.getArboles();
    for (int i = 0; i < arbolesParque.size(); i++) {
        if (arbolesParque[i] != nullptr && arbolesParque[i]->getTipoEspecie() == e->getcodigoEspecie()) {
            arbolesParque[i]->setEspecie(e);
        }
    }
}

/**
 * @brief metodo que devuelve del map especies, un map con aquellas especies coincidentes dada una subcadena
 * @param cadena
 * @return listado
 */
std::map<std::string,Especie*> ControlParques::listadoEspeciesSubNbre(const std::string& cadena) {
    std::map<std::string,Especie*> listado;
    for (std::map<std::string, Especie>::iterator it= especies.begin(); it != especies.end(); ++it) {
        const std::string& nombreCientifico = it->second.getnombre_cientifico();
        if (nombreCientifico.find(cadena)!= std::string::npos) {
            listado.insert(std::make_pair(it->first,&(it->second)));
        }
    }
    return listado;
}

/**
 * @brief metodo que busca un parque dado su nombre
 * @param nombreParque
 * @return un puntero de tipo parque hacia la posicion que ocupa
 */
Parque* ControlParques::buscarParque(const std::string& nombreParque) {
    for (std::map<int, Parque>::iterator it = parques.begin(); it != parques.end(); ++it) {
        if (it->second.get_nombre_parque() == nombreParque) {
            return &(it->second);
        }
    }
    return nullptr;
}




//METODOS PRACTICA 3
/**
 * @brief metodo que lista todos los arboles de un parque dado su asNum
 * @param asNum
 * @return vector de tipo Arbol con todos los arboles con ese asNum
 */
std::vector<Arbol *> ControlParques::listaArbParque(const std::string &asNum) {
    if (asNum.empty()) {
        throw std::invalid_argument("cadena asNum no valida");
    }
    Parque* parque = buscarParque(asNum);
    if (parque) {
        return parque->getArboles();
    }
    return std::vector <Arbol *>();
}


/**
 * @brief metodo modificado de buscar arboles, con la diferencia de que se emplea el algoritmo djb2
 * @param asNum
 * @return el arbol deseado
 */
Arbol* ControlParques::buscarArbol(const std::string& asNum) {
    return trees.buscar(djb2(asNum.c_str()));
}

/**
 * @brief metodo que busca el arbol con mayor altura
 * @return puntero al arbol mas alto
 */
Arbol *ControlParques::arbolMasAlto() {
    if (idArboles.empty()) {
        throw std::runtime_error("No hay arboles cargados");
    }
    Arbol* aMasAlto = buscarArbol(idArboles[0]);
    for (unsigned int i = 1; i < idArboles.size(); i++) {
        Arbol* a = buscarArbol(idArboles[i]);
        if (a != nullptr && a->getAltura() > aMasAlto->getAltura()) {
            aMasAlto = a;
        }
    }
    return aMasAlto;
}

/**
 * @brief metodo que se encarga de contabilizar los diferentes tipos de arboles que existen
 * @return la cantidad de tipos diferentes
 */
int ControlParques::contarTipos() {
    std::set<std::string> tiposDistintos;
    for (int i = 0; i < idArboles.size(); i++) { Arbol* a = buscarArbol(idArboles[i]);
        if (a != nullptr && !a->getTipoEspecie().empty()) {
            tiposDistintos.insert(a->getTipoEspecie());
        }
    }
    return tiposDistintos.size();
}


/**
 * @brief metodo que recorre el map de de parques para encontrar las diferentes especies que figuran en estas
 * @param nbreParque
 * @return la cantidad de especies distintas que hay
 */
int ControlParques::contarEspecies(const std::string &nbreParque) const {
    if (nbreParque.empty()) {
        throw std::invalid_argument("Nombre de parque vacio");
    }
    for (std::map<int, Parque>::const_iterator it = parques.begin(); it != parques.end(); ++it) {
        if (it->second.get_nombre_parque() == nbreParque) {
            return it->second.contarEspecies();
        }
    }
    return 0;
}

/**
 * @brief metodo que busca el parque dado su codigo
 * @param cod
 * @return direccion de memoria a la que apunta el iterador de tipo Parque
 */
Parque* ControlParques::buscarParqueCodigo(int cod) {
    std::map<int, Parque>::iterator it = parques.find(cod);
    if (it == parques.end()) {
        return nullptr;
    }
    return &(it->second);
}

/**
 * @brief metodo que busca una especie dada su codigo
 * @param cod
 * @return puntero a la especie
 */
Especie* ControlParques::buscarEspecieCodigo(const std::string& cod) {
    std::map<std::string, Especie>::iterator it = especies.find(cod);
    if (it == especies.end()) {
        return nullptr;
    }
    return &(it->second);
}

/**
 * @metodo que devuelve el numero de arboles
 * @return la cantidad de arboles
 */
unsigned int ControlParques::numArboles() const {
    return trees.numElementos();
}

/**
 * @brief metodo que dado un nombre comun, lista los parques que tienen dicho arbol
 * @param nombreComun
 * @return set con los los parques que poseen un arbol
 */
std::set<Parque*> ControlParques::listarParquesArbol(const std::string& nombreComun) {
    std::set<Parque*> resultado;
    std::pair<std::multimap<std::string, Arbol*>::iterator,
              std::multimap<std::string, Arbol*>::iterator> rango = treeName.equal_range(nombreComun);
    for (std::multimap<std::string, Arbol*>::iterator it = rango.first; it != rango.second; ++it) {
        Parque* p = it->second->getParque();
        if (p != nullptr) {
            resultado.insert(p);            // el set evita parques repetidos
        }
    }
    return resultado;
}

/**
 * @brief metodo que busca un arbol dado su nombre comun
 * @param nombreComun
 * @return vector con los arboles
 */
std::vector<Arbol*> ControlParques::buscarArbolNcomun(const std::string& nombreComun) {
    std::vector<Arbol*> resultado;
    std::pair<std::multimap<std::string, Arbol*>::iterator,
              std::multimap<std::string, Arbol*>::iterator> rango = treeName.equal_range(nombreComun);
    for (std::multimap<std::string, Arbol*>::iterator it = rango.first; it != rango.second; ++it) {
        resultado.push_back(it->second);
    }
    return resultado;
}

/**
 * @brief metodo que busca el arbol con solo su comienzo
 * @param comienzo
 * @return vector con todos los arboles que tengan dicha subcadena
 */
std::vector<Arbol*> ControlParques::buscarArbolNcomunComienzo(const std::string& comienzo) {
    if (comienzo.empty()) {
        throw std::invalid_argument("Nombre de comienzo vacio");
    }
    std::vector<Arbol*> resultado;
    std::multimap<std::string, Arbol*>::iterator it = treeName.lower_bound(comienzo);
    while (it != treeName.end() && it->first.compare(0, comienzo.size(), comienzo) == 0) {
        resultado.push_back(it->second);
        ++it;
    }
    return resultado;
}

/**
 * @brief metodo que cuenta los arboles correspondientes a un barrio
 * @param numBarrio
 * @return contador
 */
int ControlParques::contarArbolesBarrio(int numBarrio)  {
    int contador = 0;
    for (unsigned int i =0; i< idArboles.size(); ++i) {
        Arbol*a = buscarArbol(idArboles[i]);
        if (a != nullptr && a->getNumBarrio() == numBarrio) {
            contador++;
        }

    }
    return contador;
}

//NUEVOS METODOS PRACTICA 5
/**
 * @brief algoritmo djb2
 * @param str
 * @return hash
 */
unsigned long ControlParques::djb2(const char* str) {
    unsigned long hash = 5381;
    char c;
    while ((c = *str++) != 0) {
        hash = ((hash << 5) + hash) + c;
    }
    return hash;
}

/**
 * @brief metodo que busca los arboles que poseen un nido dado el numero de barrio
 * @param ndistrito
 * @return vector de tipo arbol
 */
std::vector<Arbol *> ControlParques::arbolesCajaDistrito(std::string &ndistrito) {
    std::set<Arbol *> unicos;
    for (std::size_t i = 0; i < nests.size(); ++i) {
        if (nests[i].estaEnArbol() && nests[i].getDistrito().find(ndistrito) != std::string::npos) {
            unicos.insert(nests[i].getArbol());
        }
    }
    return std::vector<Arbol *>(unicos.begin(), unicos.end());
}

/**
 * @brief metodo que busca aquellos nidos en el nombre del distrito
 * @param nbre_distrito
 * @return vector
 */
std::vector<CajaNido *> ControlParques::cajasEnDistrito(std::string &nbre_distrito) {
    std::vector<CajaNido *> resultado;
    for (std::size_t i = 0; i < nests.size(); ++i) {
        if (nests[i].getDistrito().find(nbre_distrito) != std::string::npos) {
            resultado.push_back(&nests[i]);
        }
    }
    return resultado;
}

unsigned int ControlParques::contarCajasEnArbol() const {
    unsigned int contador = 0;
    for (std::size_t i = 0; i < nests.size(); ++i) {
        if (nests[i].estaEnArbol()) {
            ++contador;
        }
    }
    return contador;
}


const std::vector<CajaNido>& ControlParques::get_nests() const {
    return nests;
}

CajaNido* ControlParques::buscarCajaNido(unsigned int linea) {
    if (linea < 2 || linea - 2 >= nests.size()) {
        return nullptr;
    }
    return &nests[linea - 2];
}

std::vector<Parque*> ControlParques::parquesConCajaNido() {
    std::set<Parque*> unicos;
    for (unsigned int i = 0; i < nests.size(); i++) {
        if (nests[i].estaEnArbol()) {
            Parque* p = nests[i].getArbol()->getParque();
            if (p != nullptr) {
                unicos.insert(p);
            }
        }
    }
    return std::vector<Parque*>(unicos.begin(), unicos.end());
}

//Metodos para el main Tabla hash
void ControlParques::mostrarEstadoTabla()const {
    return trees.mostrarEstadoTabla();
}

/**
 * @brief metodo que realiza la prueba de rendimiento de la tabla hash y la lista
 * @param n
 */
void ControlParques::compararBusquedas(unsigned int n) {
    if (n > idArboles.size()) n = idArboles.size();

    std::vector<std::string> ids(idArboles);
    std::mt19937 gen(12345);
    std::shuffle(ids.begin(), ids.end(), gen);
    ids.resize(n);

    // Tabla hash: O(1) de media por búsqueda
    unsigned int encHash =0;
    auto t0=  std::chrono::steady_clock::now();
    for (unsigned int i  = 0; i <  n; i++) {
        if (buscarArbol(ids[i]) !=  nullptr)  encHash++;
    }
    auto t1 = std::chrono::steady_clock::now();
    unsigned int encLista = 0;
    for (unsigned int i = 0; i <n; i++) {
        for (std::list<Arbol>::iterator it= listaArboles.begin(); it != listaArboles.end(); ++it) {
            if (it->getAssetnum() == ids[i]) { encLista++; break; }
        }
    }
    auto t2=std::chrono::steady_clock::now();

    double msHash=std::chrono::duration<double,std::milli>(t1 - t0).count();
    double msLista=std::chrono::duration<double, std::milli>(t2 - t1).count();

    std::cout << "\n--- COMPARACION DE BUSQUEDAS ---" << std::endl;
    std::cout <<"Identificadores seleccionados: " <<n << std::endl;
    std::cout <<"Encontrados en hash: " << encHash <<std::endl;
    std::cout <<"Encontrados en lista: " << encLista <<std::endl;
    std::cout <<"Tiempo hash: " << msHash << " ms" <<std::endl;
    std::cout <<"Tiempo lista: " << msLista <<" ms"<< std::endl;
}

/**
 * @brief metodo que calcula el tamaño de la tabla
 * @return tamTabla
 */
unsigned int ControlParques::tamTabla() const {
    return trees.tamTabla();
}

/**
 * @brief metodo que devuelve los ids de los arboles que poseen nidos
 * @return vector de string
 */
std::vector<std::string> ControlParques:: idsArbolDeCajas() const {
    std::vector<std::string> ids(nests.size());
    for (unsigned int i = 0; i < nests.size(); i++) {
        if (nests[i].estaEnArbol()) {
            ids[i]=nests[i].getArbol()->getAssetnum();
        }
    }
    return ids;
}

/**
 * @brief metodo que nos permite reconstruir con el nuevo tamaño de la tabla hash
 * @param idsCajas
 */
void ControlParques::reconstruirEnlaces(const std::vector<std::string>& idsCajas){
    for (std::map<int, Parque>:: iterator it =parques.begin(); it != parques.end(); it++) {
        it->second.vaciarArboles();

    }
    treeName.clear();
    for (unsigned int i = 0; i < idArboles.size(); i++) {
        Arbol* arb= buscarArbol(idArboles[i]);
        if (arb != nullptr) {
            if (arb->getParque() != nullptr) {
                arb->getParque()->insertarArbol(arb);
            }

            if (arb->getEspecie() != nullptr) {
                treeName.insert(std::make_pair(arb->getNbreComun(), arb));
            }
        }
    }

    for (unsigned int i = 0; i < idsCajas.size(); i++) {
        if (idsCajas[i].empty()) {
            nests[i].setArbol(nullptr);
        }else {
            nests[i].setArbol(buscarArbol(idsCajas[i]));
        }

    }
}

/**
 * @brief funcion recursiva de redispersion
 * @param n
 */
void ControlParques::redispersar(unsigned int n) {
    std::vector<std::string> idsCajas=idsArbolDeCajas();
    trees.redispersar(n);
    reconstruirEnlaces(idsCajas);
}