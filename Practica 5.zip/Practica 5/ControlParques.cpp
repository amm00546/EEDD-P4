//
// Created by a_amo on 07/10/2026.
//

#include "ControlParques.h"
#include "LectorCSV.h"
#include <stdexcept>
#include <algorithm>

ControlParques::ControlParques(const std::string& rutaEspecies,
    const std::string& rutaParques, const std::string& rutaArboles, const std::string& rutaCajasNido, float lambda, int tipoHash):
    trees(134438, lambda, tipoHash) {
    LectorCSV lector;

    if (!lector.cargar(especies, rutaEspecies)) {
        throw std::runtime_error("ControlParques: No se pudo abrir " + rutaEspecies);
    }

    if (!lector.cargarParques(parques, rutaParques)) {
        throw std::runtime_error("ControlParques: No se pudo abrir " + rutaParques);
    }

    // Vector temporal para guardar los punteros a los árboles mientras se cargan
    std::vector<Arbol*> listaArboles;

    bool ok = lector.cargarArboles(rutaArboles, [this, &listaArboles](Arbol& leido, const std::string& codEspecie) {
        unsigned long clave = djb2(leido.getAssetnum().c_str());
        if (!trees.insertar(clave, leido)) {
            return;
        }
        Arbol* a = trees.buscar(clave);
        idArboles.push_back(a->getAssetnum());
        listaArboles.push_back(a);
        a->setEspecie(buscarEspecieCodigo(codEspecie));

        Parque* p = buscarParqueCodigo(a->getNumParque());
        if (p != nullptr) {
            p->insertarArbol(a);
            a->setParque(p);
        }

        if (a->getEspecie() != nullptr) {
            treeName.insert(std::make_pair(a->getNbreComun(), a));
        }
    });

    if (!ok) {
        throw std::runtime_error("ControlParques: no se pudo abrir " + rutaArboles);
    }

    if (!lector.cargarCajasNido(nests, rutaCajasNido)) {
        throw std::runtime_error("ControlParques: no se pudo abrir " + rutaCajasNido);
    }

    // Asociar cada caja nido al árbol más cercano (a menos de 10 metros)
    for (unsigned int i = 0; i < nests.size(); i++) {
        Arbol* masCercano = nullptr;
        double minDist2 = 100.0;
        double cx = nests[i].getCoord().getX();
        double cy = nests[i].getCoord().getY();

        for (unsigned int j = 0; j < listaArboles.size(); j++) {
            Arbol* a = listaArboles[j];
            double dx = a->getCoord().getX() - cx;
            if (dx >= 10.0 || dx <= -10.0) continue;

            double dy = a->getCoord().getY() - cy;
            if (dy >= 10.0 || dy <= -10.0) continue;

            double d2 = dx * dx + dy * dy;
            if (d2 < minDist2) {
                minDist2 = d2;
                masCercano = a;
            }
        }
        nests[i].setArbol(masCercano);
    }
}

std::map<std::string,Especie>& ControlParques::get_especies() {
    return this->especies;
}

std::map<int,Parque>& ControlParques::get_parques() {
    return this->parques;
}

int ControlParques::contarEspecieParque(const std::string& nComun) {
    if (nComun.empty()) {
        throw std::invalid_argument("Nombre comun vacio");

    }
    return listarParquesArbol(nComun).size();
}

void ControlParques::asignarEspecieParque(Especie* e, Parque& p) {
    if (e==nullptr) {
        return;
    }
    std::vector<Arbol*> arbolesParque = p.getArboles();
    for (int i = 0; i < arbolesParque.size(); i++) {
        if (arbolesParque[i] != nullptr && arbolesParque[i]->getTipoEspecie() == e->getcodigoEspecie()) {
            arbolesParque[i]->setEspecie(e);
        }
    }
}


std::map<std::string,Especie*> ControlParques::listadoEspeciesSubNbre(const std::string& cadena) {
    std::map<std::string,Especie*> listado;
    for (std::map<std::string, Especie>::iterator it= especies.begin(); it != especies.end(); ++it) {
        const std::string& nombreCientifico = it->second.getnombre_cientifico();
        if (nombreCientifico.find(cadena)!= std::string::npos) {
            listado.insert(std::make_pair(it->first,&(it->second)));
        }
    }
    return listado;
}





Parque* ControlParques::buscarParque(const std::string& nombreParque) {
    for (std::map<int, Parque>::iterator it = parques.begin(); it != parques.end(); ++it) {
        if (it->second.get_nombre_parque() == nombreParque) {
            return &(it->second);
        }
    }
    return nullptr;
}




//METODOS PRACTICA 3
std::vector<Arbol *> ControlParques::listaArbParque(const std::string &asNum) {
    if (asNum.empty()) {
        throw std::invalid_argument("cadena asNum no valida");
    }
    Parque* parque = buscarParque(asNum);
    if (parque) {
        return parque->getArboles();
    }
    return std::vector <Arbol *>();
}


Arbol* ControlParques::buscarArbol(const std::string& asNum) {
    return trees.buscar(djb2(asNum.c_str()));
}

Arbol *ControlParques::arbolMasAlto() {
    if (idArboles.empty()) {
        throw std::runtime_error("No hay arboles cargados");
    }
    Arbol* aMasAlto = buscarArbol(idArboles[0]);
    for (unsigned int i = 1; i < idArboles.size(); i++) {
        Arbol* a = buscarArbol(idArboles[i]);
        if (a != nullptr && a->getAltura() > aMasAlto->getAltura()) {
            aMasAlto = a;
        }
    }
    return aMasAlto;
}

int ControlParques::contarTipos() {
    std::set<std::string> tiposDistintos;
    for (int i = 0; i < idArboles.size(); i++) { Arbol* a = buscarArbol(idArboles[i]);
        if (a != nullptr && !a->getTipoEspecie().empty()) {
            tiposDistintos.insert(a->getTipoEspecie());
        }
    }
    return tiposDistintos.size();
}



int ControlParques::contarEspecies(const std::string &nbreParque) const {
    if (nbreParque.empty()) {
        throw std::invalid_argument("Nombre de parque vacio");
    }
    for (std::map<int, Parque>::const_iterator it = parques.begin(); it != parques.end(); ++it) {
        if (it->second.get_nombre_parque() == nbreParque) {
            return it->second.contarEspecies();
        }
    }
    return 0;
}


Parque* ControlParques::buscarParqueCodigo(int cod) {
    std::map<int, Parque>::iterator it = parques.find(cod);
    if (it == parques.end()) {
        return nullptr;
    }
    return &(it->second);
}


Especie* ControlParques::buscarEspecieCodigo(const std::string& cod) {
    std::map<std::string, Especie>::iterator it = especies.find(cod);
    if (it == especies.end()) {
        return nullptr;
    }
    return &(it->second);
}

unsigned int ControlParques::numArboles() const {
    return trees.numElementos();
}


std::set<Parque*> ControlParques::listarParquesArbol(const std::string& nombreComun) {
    std::set<Parque*> resultado;
    std::pair<std::multimap<std::string, Arbol*>::iterator,
              std::multimap<std::string, Arbol*>::iterator> rango = treeName.equal_range(nombreComun);
    for (std::multimap<std::string, Arbol*>::iterator it = rango.first; it != rango.second; ++it) {
        Parque* p = it->second->getParque();
        if (p != nullptr) {
            resultado.insert(p);            // el set evita parques repetidos
        }
    }
    return resultado;
}

std::vector<Arbol*> ControlParques::buscarArbolNcomun(const std::string& nombreComun) {
    std::vector<Arbol*> resultado;
    std::pair<std::multimap<std::string, Arbol*>::iterator,
              std::multimap<std::string, Arbol*>::iterator> rango = treeName.equal_range(nombreComun);
    for (std::multimap<std::string, Arbol*>::iterator it = rango.first; it != rango.second; ++it) {
        resultado.push_back(it->second);
    }
    return resultado;
}


std::vector<Arbol*> ControlParques::buscarArbolNcomunComienzo(const std::string& comienzo) {
    if (comienzo.empty()) {
        throw std::invalid_argument("Nombre de comienzo vacio");
    }
    std::vector<Arbol*> resultado;
    std::multimap<std::string, Arbol*>::iterator it = treeName.lower_bound(comienzo);
    while (it != treeName.end() && it->first.compare(0, comienzo.size(), comienzo) == 0) {
        resultado.push_back(it->second);
        ++it;
    }
    return resultado;
}

int ControlParques::contarArbolesBarrio(int numBarrio)  {
    int contador = 0;
    for (unsigned int i =0; i< idArboles.size(); ++i) {
        Arbol*a = buscarArbol(idArboles[i]);
        if (a != nullptr && a->getNumBarrio() == numBarrio) {
            contador++;
        }

    }
    return contador;
}

//NUEVOS METODOS PRACTICA 5
unsigned long ControlParques::djb2(const char* str) {
    unsigned long hash = 5381;
    char c;
    while ((c = *str++) != 0) {
        hash = ((hash << 5) + hash) + c;
    }
    return hash;
}

std::vector<Arbol *> ControlParques::arbolesCajaDistrito(std::string &ndistrito) {
    std::set<Arbol *> unicos;
    for (std::size_t i = 0; i < nests.size(); ++i) {
        if (nests[i].estaEnArbol() && nests[i].getDistrito().find(ndistrito) != std::string::npos) {
            unicos.insert(nests[i].getArbol());
        }
    }
    return std::vector<Arbol *>(unicos.begin(), unicos.end());
}

std::vector<CajaNido *> ControlParques::cajasEnDistrito(std::string &nbre_distrito) {
    std::vector<CajaNido *> resultado;
    for (std::size_t i = 0; i < nests.size(); ++i) {
        if (nests[i].getDistrito().find(nbre_distrito) != std::string::npos) {
            resultado.push_back(&nests[i]);
        }
    }
    return resultado;
}

unsigned int ControlParques::contarCajasEnArbol() const {
    unsigned int contador = 0;
    for (std::size_t i = 0; i < nests.size(); ++i) {
        if (nests[i].estaEnArbol()) {
            ++contador;
        }
    }
    return contador;
}


const std::vector<CajaNido>& ControlParques::get_nests() const {
    return nests;
}

CajaNido* ControlParques::buscarCajaNido(unsigned int linea) {
    if (linea < 2 || linea - 2 >= nests.size()) {
        return nullptr;
    }
    return &nests[linea - 2];
}

std::vector<Parque*> ControlParques::parquesConCajaNido() {
    std::set<Parque*> unicos;
    for (unsigned int i = 0; i < nests.size(); i++) {
        if (nests[i].estaEnArbol()) {
            Parque* p = nests[i].getArbol()->getParque();
            if (p != nullptr) {
                unicos.insert(p);
            }
        }
    }
    return std::vector<Parque*>(unicos.begin(), unicos.end());
}

//Metodos para el main Tabla hash
void ControlParques::mostrarEstadoTabla()const {
    return trees.mostrarEstadoTabla();
}

void ControlParques::compararBusquedas(unsigned int n) {
    if (n > idArboles.size()) n = idArboles.size();

    // n identificadores DISTINTOS al azar: barajar una copia y coger los n primeros
    std::vector<std::string> ids(idArboles);
    std::mt19937 gen(12345);                      // semilla fija: mismos ids en las 6 pruebas
    std::shuffle(ids.begin(), ids.end(), gen);
    ids.resize(n);

    // Tabla hash: O(1) de media por búsqueda
    unsigned int encHash =0;
    auto t0= std::chrono::steady_clock::now();
    for (unsigned int i = 0; i < n; i++) {
        if (buscarArbol(ids[i]) != nullptr) encHash++;
    }
    auto t1 = std::chrono::steady_clock::now();

    // Lista: búsqueda secuencial O(n)
    unsigned int encLista = 0;
    for (unsigned int i = 0; i <n; i++) {
        for (std::list<Arbol>::iterator it= listaArboles.begin(); it != listaArboles.end(); ++it) {
            if (it->getAssetnum() == ids[i]) { encLista++; break; }
        }
    }
    auto t2=std::chrono::steady_clock::now();

    double msHash=std::chrono::duration<double, std::milli>(t1 - t0).count();
    double msLista=std::chrono::duration<double, std::milli>(t2 - t1).count();

    std::cout << "\n--- COMPARACION DE BUSQUEDAS ---" << std::endl;
    std::cout << "Identificadores seleccionados: " <<n << std::endl;
    std::cout << "Encontrados en hash: " << encHash <<std::endl;
    std::cout << "Encontrados en lista: " << encLista <<std::endl;
    std::cout << "Tiempo hash: " << msHash << " ms" <<std::endl;
    std::cout << "Tiempo lista: " << msLista <<" ms"<< std::endl;
}
