//
// Created by palega on 18/11/2026.
//

#ifndef PRACTICA_5_CAJANIDO_H
#define PRACTICA_5_CAJANIDO_H

#include <string>
#include "UTM.h"
#include "Arbol.h"
class CajaNido {
private:
    std::string distrito;
    std::string barrio;
    std::string ubicacion;
    UTM coord;
    Arbol* itsTree;
public:
    //CONSTRUCTORES
    CajaNido(const std::string& distrito, const std::string& barrio, const std::string &ubicacion, UTM coord);
    CajaNido();
    CajaNido(const CajaNido& orig);

    //NUEVOS METODOS
    void setArbol(Arbol* a);
    Arbol *getArbol() const;
    bool estaEnArbol() const;

    //GETTERS
    const UTM& getCoord();
    const std::string& getDistrito();
    const std::string& getBarrio();
    const std::string& getUbicacion();

};


#endif //PRACTICA_5_CAJANIDO_H