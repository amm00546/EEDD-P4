#include <cmath>
#include <exception>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>
//Arreglar caracteres especiales por pantalla
#ifdef _WIN32
#include <windows.h>
#endif


#include "ControlParques.h"
#include "Arbol.h"
#include "CajaNido.h"
#include "LectorCSV.h"
#include <list>
#include <chrono>
#include <random>
#include <map>
#include "Especie.h"
#include <algorithm>

using namespace std;

//Rutas de los archivos
const string RUTA_ESPECIES = "arbolado-especies.csv";
const string RUTA_PARQUES = "parques.csv";
const string RUTA_ARBOLES = "arboladoMadrid.csv";
const string RUTA_CAJAS_NIDO = "cajas-nido.csv";

/**
 * @brief Muestra una posición UTM con sus decimales
 */
void mostrarCoordenadas(const UTM &coord) {
    cout << fixed << setprecision(3) << "(" << coord.getX() << ", " << coord.getY() << ")"
            << defaultfloat << setprecision(6);
}

int main() {
    //Arreglar caracteres especiales por pantalla
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
#endif

   try {
       cout << "====================================\n";
        cout << "PROGRAMA DE PRUEBA I \n";
        cout << "====================================\n\n";

        LectorCSV lector;
        vector<Arbol> varboles;
        list<Arbol> listaArboles;
        vector<string> idArboles;

        bool ok = lector.cargarArboles(RUTA_ARBOLES, [&](Arbol& leido, const string& codEspecie) {
            varboles.push_back(leido);
            listaArboles.push_back(leido);
            idArboles.push_back(leido.getAssetnum());
        });

        if (ok == false) {
            throw runtime_error("No se puede abrir " + RUTA_ARBOLES);
        }

        // Seleccionar los 2000 IDs aleatorios una vez para comparar todas las configuraciones
        vector<string> muestra = idArboles;
        mt19937 gen(42);
        shuffle(muestra.begin(), muestra.end(), gen);
        if (muestra.size() > 2000) {
            muestra.resize(2000);
        }

        int numeroDatos = varboles.size();
        float lambdas[2] = {0.65f, 0.68f};
        int tiposHash[3] = {1, 2, 3}; // 1, 2, 3 internos que corresponden a 0, 1, 2 del profesor
        int numExperimento = 1;

       map<string, Especie> mapaEspecies;
       lector.cargar(mapaEspecies, RUTA_ESPECIES);

       map<int, Parque> mapaParques;
       lector.cargarParques(mapaParques, RUTA_PARQUES);

       vector<CajaNido> vcajas;
       lector.cargarCajasNido(vcajas, RUTA_CAJAS_NIDO);

        for (int j = 0; j < 2; j++) {
            float lamb = lambdas[j];
            for (int i = 0; i < 3; i++) {
                int t = tiposHash[i];

                cout << "===================================="<<endl;
                cout << "EXPERIMENTO " << numExperimento << endl;
                cout << "Factor de carga: " << lamb << endl;
                cout << "Función de exploración: " << i << endl;
                cout << "===================================="<<endl;
                cout << "Especies cargadas: " << mapaEspecies.size() <<endl;
                cout << "Parques cargados: " << mapaParques.size() << endl;
                cout << "Árboles cargados: " << numeroDatos << endl;
                cout << "Cajas nido cargadas: " << vcajas.size() << endl;
                cout<<endl;

                ThashArbol tabla(numeroDatos, lamb, t);
                for (int k = 0; k < numeroDatos; k++) {
                    unsigned long clave = ControlParques::djb2(varboles[k].getAssetnum().c_str());
                    tabla.insertar(clave, varboles[k]);
                }
                tabla.mostrarEstadoTabla();

                // Comparación de 2000 búsquedas para este experimento
                int encontradosHash = 0;
                auto t1 = chrono::high_resolution_clock::now();
                for (int m = 0; m < (int)muestra.size(); m++) {
                    if (tabla.buscar(ControlParques::djb2(muestra[m].c_str())) != nullptr) {
                        encontradosHash++;
                    }
                }
                auto t2 = chrono::high_resolution_clock::now();
                double msHash = chrono::duration<double, milli>(t2 - t1).count();

                int encontradosLista = 0;
                auto t3 = chrono::high_resolution_clock::now();
                for (int m = 0; m < (int)muestra.size(); m++) {
                    bool encontrado = false;
                    for (list<Arbol>::iterator it = listaArboles.begin(); it != listaArboles.end() && !encontrado; it++) {
                        if (it->getAssetnum() == muestra[m]) {
                            encontrado = true;
                            encontradosLista++;
                        }
                    }
                }
                auto t4 = chrono::high_resolution_clock::now();
                double msLista = chrono::duration<double, milli>(t4 - t3).count();

                cout<<endl;
                cout <<" COMPARACIÓN DE BÚSQUEDAS "<<endl;
                cout <<"Identificadores seleccionados: "<<muestra.size()<<endl;
                cout <<"Encontrados en hash: "<<encontradosHash<<endl;
                cout <<"Encontrados en lista: "<<encontradosLista<<endl;
                cout <<"Tiempo hash: "<< msHash <<" ms"<<endl;
                cout <<"Tiempo lista: "<< msLista <<" ms"<<endl;

                numExperimento++;
            }
        }

   }catch (const std::exception& error) {
       std::cerr <<"Error en la prueba 1: "<<error.what() <<endl;
       return 1;
   }

    try {
        ControlParques control(
            RUTA_ESPECIES,
            RUTA_PARQUES,
            RUTA_ARBOLES,
            RUTA_CAJAS_NIDO);

        cout << "\nPROGRAMA DE PRUEBA 2\n";



        cout << "\nAPARTADO 1: BÚSQUEDA DE ÁRBOLES POR ASSETNUM\n";
        const string ARBOLES_APARTADO_1[] = {"6925456", "6635839", "5222166"};
        for (const string &assetnum: ARBOLES_APARTADO_1) {
            Arbol *arbol = control.buscarArbol(assetnum);
            if (arbol == nullptr) {
                cout << "Árbol " << assetnum << ": no encontrado" << endl;
                continue;
            }
            cout << "Árbol " << assetnum << ": especie " << arbol->getNbreComun()
                    << " (" << arbol->getNbreCientifico() << "), altura " << arbol->getAltura()
                    << " m, parque " << arbol->getNumParque() << endl;
        }

        cout << "\nAPARTADO 2: ÁRBOLES CON CAJA NIDO EN EL DISTRITO CENTRO\n";
        string DISTRITO = "CENTRO";
        vector<Arbol *> arbolesConCaja = control.arbolesCajaDistrito(DISTRITO);
        cout << "\tÁrboles encontrados: " << arbolesConCaja.size() << endl;
        for (Arbol *arbol: arbolesConCaja) {
            cout << "\t" << arbol->getAssetnum() << " - " << arbol->getNbreComun()
                    << " - " << arbol->getNombreDistrito() << endl;
        }

        cout << "\nAPARTADO 3: CAJAS NIDO ASOCIADAS A UN ÁRBOL\n";
        unsigned int cajasEnArbol = control.contarCajasEnArbol();
        cout << "\tCajas nido asociadas a un árbol: " << cajasEnArbol << endl;
        cout << "\tCajas nido sin asociar: " << control.get_nests().size() - cajasEnArbol << endl;

        cout << "\nAPARTADO 4: CAJAS NIDO EN EL DISTRITO CENTRO\n";
        vector<CajaNido *> cajasDistrito = control.cajasEnDistrito(DISTRITO);
        cout << "\tCajas nido encontradas: " << cajasDistrito.size() << endl;
        for (int i = 0; i < cajasDistrito.size(); i++) {
            CajaNido* caja = cajasDistrito[i];
            cout<<"Caja "<<i+1<<" ("<< caja->getUbicacion() << "): ";
            if (caja->estaEnArbol()) {
                cout << "asociada al árbol " << caja->getArbol()->getAssetnum() << endl;
            } else {
                cout << "sin asociar" << endl;
            }
        }

        cout << "\nAPARTADO 5: DETALLE DE CINCO CAJAS NIDO\n";
        const unsigned int CAJAS_APARTADO_5[] = {70, 75, 80, 85, 90};
        for (unsigned int linea: CAJAS_APARTADO_5) {
            CajaNido *caja = control.buscarCajaNido(linea);
            if (caja == nullptr) {
                cout << "\tCaja de la línea " << linea << " no encontrada" << endl << endl;
                continue;
            }
            cout << "\t" << "caja de la línea " << linea << endl;
            cout << "\t" << "coordenadas de la caja: ";
            mostrarCoordenadas(caja->getCoord());
            cout << endl;
            if (caja->estaEnArbol()) {
                Arbol *arbol = caja->getArbol();
                double distancia2 = caja->getCoord().distancia2(arbol->getCoord());
                cout << "\t" << "identificador del árbol: " << arbol->getAssetnum() << endl;
                cout << "\t" << "coordenadas del árbol: ";
                mostrarCoordenadas(arbol->getCoord());
                cout << endl;
                cout << "\t" << "distancia: " << fixed << setprecision(2) << sqrt(distancia2) << " m"
                        << " (al cuadrado " << distancia2 << ")" << defaultfloat << setprecision(6) << endl;
                cout << "\t" << (distancia2 < 100 ? "cumple" : "NO cumple")
                        << " la condición de estar a menos de 10 metros" << endl;
            } else {
                cout << "\t" << "sin árbol asociado: no hay ninguno a menos de 10 metros" << endl;
            }
            cout << endl;
        }

        cout << "APARTADO 6: PARQUES CON ALGUNA CAJA NIDO\n";
        vector<Parque *> parquesConCaja = control.parquesConCajaNido();
        cout << "\tParques encontrados: " << parquesConCaja.size() << endl;
        for (Parque *pq: parquesConCaja) {
            cout << "\t" << pq->get_codigo_parque() << " - " << pq->get_nombre_parque() << endl;
        }

    } catch (const std::exception &error) {
        std::cerr << "\nError: " << error.what() << '\n';
        return 1;
    }

    return 0;
};
