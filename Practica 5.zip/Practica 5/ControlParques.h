//
// Created by a_amo on 07/10/2026.
//

#ifndef PRACTICA_3_CONTROLPARQUES_H
#define PRACTICA_3_CONTROLPARQUES_H


#include <string>
#include "Especie.h"
#include "Parque.h"
#include "ThashArbol.h"
#include "Arbol.h"
#include <vector>
#include <list>
#include <map>
#include <set>
#include "CajaNido.h"


class ControlParques {
private:
    std::map<std::string, Especie> especies;
    std::map<int, Parque> parques;
    ThashArbol trees;
    std::multimap <std::string, Arbol*> treeName;
    std::vector<CajaNido> nests;
    std::vector<std::string> idArboles;
public:
    ControlParques(const std::string& rutaEspecies, const std::string& rutaParques, const std::string& rutaArboles);
    std::map<std::string,Especie>& get_especies();
    std::map<int ,Parque>& get_parques();

    //Metodos del UML
    int contarEspecieParque(const std::string& nComun);

    /**
     * @brief metodo al que a cada especie se le asigna un parque
     * @param e
     * @param p
     */
    void asignarEspecieParque(Especie* e, Parque& p);

    /**
     * @pre que el nombre del parque no este vacio
     * @brief metodo de busqueda de un parque dado un nombre
     * @param nombreParque
     * @return puntero al parque que se desea buscar
     */
    Parque* buscarParque(const std::string& nombreParque);

    /**
     * @pre que la subcadena no este vacia
     * @metodo de busqueda comun de especies dada una subcadena
     * @param cadena
     * @return vector dinamico de especies
     */
    std::map<std::string, Especie*> listadoEspeciesSubNbre(const std::string& cadena);

    //UML PRACTICA 3
    /**
     * @pre que el asNum no este vacio
     * @brief metodo que crea un listado de arboles de un parque, dado su identificador
     * @param asNum
     * @return vector dinamico de arboles
     */
    std::vector<Arbol*>listaArbParque(const std::string& asNum);

    /**
     * @pre que el identificador no este vacio
     * @brief metodo de busqueda de un arbol dado su identificador
     * @param asNum
     * @return puntero al arbol deseado
     */
    Arbol* buscarArbol(const std::string& asNum);

    /**
     * @brief metodo de busuqeda que obtiene el arbol mas alto
     * @return puntero al arbol mas alto
     */
    Arbol* arbolMasAlto() ;

    /**
     * @brief metodo que cuenta los diferentes tipos de especie
     * @return el tamaño de la estructura
     */
    int contarTipos();
    /**
     * @brief metodo que cuenta las diferentes especies
     * @return el tamaño de la estructura
     */
    int contarEspecies(const std::string& nbreParque) const;


    //UML PRACTICA 4
    /**
     * @pre que el nombre comun no este vacio
     * @brief metodo que busca coincidencias de los parques con un nombre dado
     * @param nombreComun
     * @return set de parques con el nombre comun dado
     */
    std::set<Parque*> listarParquesArbol(const std::string& nombreComun);

    /**
     * @brief metodo que busca un arbol dado un nombre comun
     * @param nombreComun
     * @return un vector dinamico de arboles
     */
    std::vector<Arbol*> buscarArbolNcomun(const std::string& nombreComun);

    /**
     * @brief metodo que busca un arbol dado una subcadena del inicio de su nombre
     * @param comienzo
     * @return
     */
    std::vector<Arbol*> buscarArbolNcomunComienzo(const std::string& comienzo);

    /**
     *
     * @param numBarrio
     * @return
     */
    int contarArbolesBarrio(int numBarrio) ;

    /**
     * @metodo que busca un parque dado un codigo
     * @param cod
     * @return puntero al parque que tenga ese codigo
     */
    Parque* buscarParqueCodigo(int cod);

    /**
     * @brief metodo de busqueda de una especie dado su codigo
     * @param cod
     * @return puntero a la especie que posee dicho codigo
     */
    Especie* buscarEspecieCodigo(const std::string& cod);

    /**
     *
     * @return numero de arboles
     */
    unsigned int numArboles() const;

    //PAREJAS
    /**
     * @brief metodo que busca un arbol dado su nombre comun y distrito
     * @param nbreComun
     * @param numDistrito
     * @return un vector resultante de los parametros dados
     */
    std::vector<Arbol*>buscarArbolPorEspecieYDistrito(const std::string& nbreComun, int numDistrito);


    //NUEVOS METODOS PRACTICA 5

};


#endif //PRACTICA_3_CONTROLPARQUES_H