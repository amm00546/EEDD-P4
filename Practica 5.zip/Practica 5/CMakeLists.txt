cmake_minimum_required(VERSION 4.0)
project(Practica_5)

set(CMAKE_CXX_STANDARD 14)

include_directories(.)

add_executable(Practica_5
        Arbol.cpp
        Arbol.h
        ControlParques.cpp
        ControlParques.h
        Especie.cpp
        Especie.h
        LectorCSV.cpp
        LectorCSV.h
        main.cpp
        Parque.cpp
        Parque.h
        UTM.cpp
        UTM.h
        CajaNido.cpp
        CajaNido.h
        ThashArbol.cpp
        ThashArbol.h
)
