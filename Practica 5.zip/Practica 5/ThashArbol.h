//
// Created by Pablo on 21/11/2026.
//

#ifndef PRACTICA_5_THASHARBOL_H
#define PRACTICA_5_THASHARBOL_H
#include <iostream>
#include <string>
#include <vector>
#include "Arbol.h"

class ThashArbol {
private:
    enum class Estado {VACIA, OCUPADA, DISPONIBLE};
    struct Entrada {
        unsigned long clave;
        Arbol dato;
        Estado estado;
        Entrada(): clave(0), dato(), estado(Estado::VACIA) {}
    };
    std::vector<Entrada> tabla;
    int nElementos;
    long primoQ;
    int tipoHash;

    int maxCol;
    int contMax10;
    long totalColisiones;
    int numInserciones;

    float lambda;
    int numRedispersiones;

    //METODOS AUXILIARES
    static bool esPrimo(long n);
    static unsigned long primoSiguiente(unsigned long n);
    static unsigned long primoMenor(unsigned long n);

    unsigned long hash(unsigned long clave, int intento) const;
    unsigned long hash1(unsigned long clave, int intento) const;
    unsigned long hash2(unsigned long clave, int intento) const;
    unsigned long hash3(unsigned long clave, int intento) const;

public:
    //CONSTRUCTORES, OPERATOR=, DESTRUCTOR
    ThashArbol(int maxElementos, float lambda= 0.65, int tipoHash= 3);
    ThashArbol(ThashArbol& tHash);
    ThashArbol& operator=(ThashArbol& tHash);
    ~ThashArbol();
    //METODOS PARA LA HASH
    bool insertar(unsigned long clave, Arbol &tree);
    Arbol* buscar(unsigned long clave);
    bool eliminar(unsigned long clave);
    unsigned int numElementos() const;

    //GETTERS
    unsigned int maxColisiones() const;
    unsigned int numMax10() const;
    unsigned int tamTabla() const;
    float promedioColisiones() const;
    float factorCarga() const;
    unsigned long getTotalColisiones() const;
    unsigned int getNumRedispersiones() const;
    void mostrarEstadoTabla() const;

    //PAREJAS
    void redispersar(unsigned int tam);
    void setLambda(float lambda2);

};


#endif //PRACTICA_5_THASHARBOL_H