//
// Created by Pablo on 21/11/2026.
//

#include "ThashArbol.h"
//METODOS PRIVADOS
bool ThashArbol:: esPrimo(long n) {
    if (n<=1) {
        return false;
    }
    if (n==2) {
        return true;
    }
    if (n%2==0) {
        return false;
    }

    for (long i = 3; i*i <=n; i+=2) {
        if (n%i==0) {
            return false;
        }
    }
    return true;
}

unsigned long ThashArbol::primoSiguiente(unsigned long n) {
    unsigned long sigPrimo=n+1;
    while (!(esPrimo(sigPrimo))) {
        sigPrimo++;
    }
    return sigPrimo;
}

unsigned long ThashArbol::primoMenor(unsigned long n) {
    unsigned long priMenor=n-1;
    while (priMenor>2 && !esPrimo(priMenor)) {
        priMenor--;
    }
    return priMenor;
}

unsigned long ThashArbol::hash(unsigned long clave, int intento) const {
    if (tipoHash==1) {
        return hash1(clave,intento);
    }else if (tipoHash==2) {
        return hash2(clave,intento);
    }else {
        return hash3(clave,intento);
    }

}

unsigned long ThashArbol::hash1(unsigned long clave, int intento) const{
    unsigned long t= tabla.size();
    unsigned long i=(unsigned long) intento;
    return (clave%t +i*i)%t;
}

unsigned long ThashArbol::hash2(unsigned long clave, int intento) const {
    unsigned long t=tabla.size();
    unsigned long h1=clave%t;
    unsigned long h2=1 + ((clave/t)%primoQ);
    return (h1 + (unsigned long)intento*h2)%t;
}

unsigned long ThashArbol::hash3(unsigned long clave, int intento) const {
    unsigned long t=tabla.size();
    unsigned long h1=clave%t;
    unsigned long h2= primoQ - (clave % primoQ);
    return (h1 + (unsigned long)intento*h2)%t;
}




//CONSTRUCTORES, OPERATOR= Y DESTRUCTOR
ThashArbol::ThashArbol(int maxElementos, float lambda, int tipoHash):
tabla(primoSiguiente((unsigned long) (maxElementos/ lambda) )),
nElementos(0),
primoQ(0),
tipoHash(tipoHash),
maxCol(0),
contMax10(0),
totalColisiones(0),
numInserciones(0),
lambda(lambda),
numRedispersiones(0)
{



    primoQ= primoMenor(tabla.size());

}

ThashArbol::ThashArbol(ThashArbol& tHash): tabla(tHash.tabla), nElementos(tHash.nElementos), primoQ(tHash.primoQ), tipoHash(tHash.tipoHash),
maxCol(tHash.maxCol), contMax10(tHash.contMax10), totalColisiones(tHash.totalColisiones),numInserciones(tHash.numInserciones), lambda(tHash.lambda), numRedispersiones(tHash.numRedispersiones)
{
}

ThashArbol& ThashArbol::operator=(ThashArbol& tHash) {
    if (this != &tHash) {
        tabla= tHash.tabla;
        nElementos= tHash.nElementos;
        primoQ= tHash.primoQ;
        tipoHash= tHash.tipoHash;
        maxCol= tHash.maxCol;
        contMax10= tHash.contMax10;
        totalColisiones= tHash.totalColisiones;
        numInserciones= tHash.numInserciones;
        lambda= tHash.lambda;
        numRedispersiones= tHash.numRedispersiones;
    }
    return *this;
}

ThashArbol::~ThashArbol() {

}


//METODOS PARA LA HASH

bool ThashArbol::insertar(unsigned long clave, Arbol &tree) {
    if (buscar(clave)!= nullptr) {
        return false;
    }
    int intento = 0;
    unsigned long pos= hash(clave,intento);
    while (tabla[pos].estado== Estado::OCUPADA) {
        intento++;
        pos= hash(clave,intento);
    }

    tabla[pos].clave= clave;
    tabla[pos].dato= tree;
    tabla[pos].estado= Estado::OCUPADA;
    nElementos++;
    //Actualizamos metricas
    totalColisiones+= intento;
    numInserciones++;
    if (intento >maxCol) {
        maxCol= intento;
    }
    if (intento >10) {
        contMax10++;
    }

    return true;
}

Arbol* ThashArbol::buscar(unsigned long clave) {
    int intento = 0;
    unsigned long pos=hash(clave, intento);
    while (tabla[pos].estado!=Estado::VACIA) {
        if (tabla[pos].clave==clave && tabla[pos].estado==Estado::OCUPADA) {
            return &tabla[pos].dato;
        }
        intento++;
        pos=hash(clave, intento);
    }
    return nullptr;
}

bool ThashArbol::eliminar(unsigned long clave) {
    int intento= 0;
    unsigned long pos= hash(clave,intento);

    while (tabla[pos].estado != Estado::VACIA) {
        if (tabla[pos].estado == Estado::OCUPADA && tabla[pos].clave == clave) {
            tabla[pos].estado= Estado::DISPONIBLE;
            nElementos--;
            return true;
        }
        intento++;
        pos= hash(clave,intento);

    }
    return false;
}

unsigned int ThashArbol::numElementos() const {
    return nElementos;
}

//ALBERTO esto  de los getters la mayoría son por parejas
unsigned int ThashArbol::maxColisiones() const {
    return maxCol;
}

unsigned int ThashArbol::numMax10() const {
    return contMax10;
}

unsigned int ThashArbol::tamTabla() const {
    return tabla.size();
}

float ThashArbol::promedioColisiones() const {
    if (numInserciones==0) {
        return 0;
    }
    return (float) totalColisiones/numInserciones;
}

float ThashArbol::factorCarga() const {
    return (float) nElementos/tabla.size();
}

unsigned long ThashArbol::getTotalColisiones() const {
    return totalColisiones;
}

unsigned int ThashArbol::getNumRedispersiones() const {
    return numRedispersiones;
}

void ThashArbol::mostrarEstadoTabla() const {
    std::cout <<"Tamano de la tabla: " << tamTabla() << std::endl;
    std::cout << "Numero de arboles: " << numElementos() << std::endl;
    std::cout << "Maximo colisiones: " << maxColisiones() << std::endl;
    std::cout << "Factor de carga: " << factorCarga() << std::endl;
    std::cout << "Promedio de colisiones: " << promedioColisiones() << std::endl;
    std::cout << "Mas de 10 colisiones: " << numMax10() << std::endl;
    std::cout << "Total colisiones: " << getTotalColisiones() << std::endl;
    std::cout << "Redispersiones: " << getNumRedispersiones() << std::endl;
}
