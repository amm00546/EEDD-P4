//
// Created by a_amo on 07/10/2026.
//

#ifndef PRACTICA_3_CONTROLPARQUES_H
#define PRACTICA_3_CONTROLPARQUES_H


#include <string>
#include "Especie.h"
#include "Parque.h"

#include "Arbol.h"
#include <vector>
#include <list>
#include <map>
#include <set>



class ControlParques {
private:
    std::vector<Especie> especies;
    std::list<Parque> parques;
    std::map<std::string, Arbol> trees;
    std::multimap <std::string, Arbol*> treeName;
public:
    ControlParques(const std::string& rutaEspecies, const std::string& rutaParques, const std::string& rutaArboles);
    std::vector<Especie>& get_especies();
    std::list<Parque>& get_parques();

    //Metodos del UML
    int contarEspecieParque(const std::string& nComun);
    void asignarEspecieParque(Especie* e, Parque& p);
    Parque* buscarParque(const std::string& nombreParque);
    std::vector<Especie*> listadoEspeciesSubNbre(const std::string& cadena);

    //UML PRACTICA 3
    std::vector<Arbol*>listaArbParque(const std::string& asNum);
    Arbol* buscarArbol(const std::string& asNum);
    Arbol* arbolMasAlto() ;
    int contarTipos() const;
    int contarEspecies(const std::string& nbreParque) const;


    //UML PRACTICA 4
    std::set<Parque*> listarParquesArbol(const std::string& nombreComun);
    std::vector<Arbol*> buscarArbolNcomun(const std::string& nombreComun);
    std::vector<Arbol*> buscarArbolNcomunComienzo(const std::string& comienzo);
    int contarArbolesBarrio(int numBarrio) const;


    Parque* buscarParqueCodigo(int cod);
    Especie* buscarEspecieCodigo(const std::string& cod);
    unsigned int numArboles() const;

    //PAREJAS
    std::vector<Arbol*>buscarArbolPorEspecieYDistrito(const std::string& nbreComun, int numDistrito);

};


#endif //PRACTICA_3_CONTROLPARQUES_H