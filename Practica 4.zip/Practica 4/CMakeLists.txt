cmake_minimum_required(VERSION 4.0)
project(practica4)

set(CMAKE_CXX_STANDARD 14)

include_directories(.)

add_executable(practica4
        Arbol.cpp
        Arbol.h
        ControlParques.cpp
        ControlParques.h
        Especie.cpp
        Especie.h
        LectorCSV.cpp
        LectorCSV.h
        main.cpp
        Parque.cpp
        Parque.h
        Timer.cpp
        Timer.h)
