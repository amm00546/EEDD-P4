//
// Created by Pablo on 19/10/2026.
//

#ifndef PRACTICA_3_AVL_H
#define PRACTICA_3_AVL_H


#include "VDinamico.h"
#include <stdexcept>


template <typename U>
class Nodo {
public:
    Nodo<U> *izq, *der;
    U dato;
    char bal;

    Nodo(const U& elemento): izq(0), der(0), dato(elemento), bal(0) {}
    Nodo(const Nodo<U>&orig):izq(orig.izq), der(orig.der), dato(orig.dato), bal(orig.bal) {}
};

template <typename T>
class AVL {
private:
    Nodo<T> *raiz;
    int tam;

    // Métodos auxiliares de modificación y reestructuración
    int insertaDato(Nodo<T>* &nodo, const T &dato);
    void rotarDerecha(Nodo<T>* &nodo);
    void rotarIzquierda(Nodo<T>* &nodo);

    // Métodos auxiliares de copia y destrucción de memoria
    Nodo<T>* copiaAvl(const Nodo<T> *p);
    void destruyeArbol(Nodo<T>* &p);

    // Métodos auxiliares de consulta y búsqueda
    T* buscaClave(Nodo<T> *p, const T &dato) const;
    void inorden(Nodo<T> *p, int nivel, VDinamico<T*> &v) const;
    unsigned int alturaPrivate(Nodo<T> *p) const;
    void buscarRango(Nodo<T> *p, const T &min, const T &max, VDinamico<T*> &resultado) const;


public:
    AVL();
    AVL( const AVL<T>& orig);
    AVL<T>& operator=(const AVL<T>& orig);
    ~AVL();

    bool inserta(const T& dato);
    T* buscaRec(const T& dato) const;
    T* buscaIt(const T& dato) const;
    VDinamico<T*> recorreEnOrden() const;
    unsigned int gettam() const;
    unsigned int altura() const;
    VDinamico<T*> buscarRango(const T& min, const T& max) const;

};
//METODOS PRIVATE

/**
 * @brief metodo de rotacion a derechas que permite equilibrar el AVL si hay un desbalance por el subarbol izquierdo
 * @param nodo
 */
template<typename T>
void AVL<T>::rotarDerecha(Nodo<T> *&nodo) {
    Nodo<T> *q = nodo, *l;
    nodo = l = q->izq;
    q->izq = l->der;
    l->der = q;
    q->bal--;
    if (l->bal > 0) q->bal -= l->bal;
    l->bal--;
    if(q->bal < 0) l->bal -= -q->bal;
}

/**
 * @brief rotacion a izquierdas para equilibrar el AVL si hay un desbalance por el subarbol derecho
 * @param nodo
 */
template<typename T>
void AVL<T>::rotarIzquierda(Nodo<T> *&nodo) {
    Nodo<T> *q = nodo, *r;
    nodo = r = q->der;
    q->der = r->izq;
    r->izq = q;
    q->bal++;
    if (r->bal < 0) {
        q->bal += -r->bal;
    }
    r->bal++;
    if(q->bal > 0) {
        r->bal += q->bal;
    }

}


template<typename T>
int AVL<T>::insertaDato(Nodo<T>* &nodo, const T &dato) {
    Nodo<T>* p = nodo;
    int deltaH = 0;

    if (!p) {
        p = new Nodo<T>(dato);
        nodo = p;
        tam++;
        return 1;
    }

    if (dato > p->dato) { //Por la derecha
        if (insertaDato(p->der, dato)) {
            p->bal--;
            if (p->bal == -1) {
                deltaH = 1;
            } else if (p->bal == -2) {
                if (p->der->bal == 1) {
                    rotarDerecha(p->der);
                }
                rotarIzquierda(nodo);
                p= nodo;
            }
        }
    } else if (dato < p->dato) { //Insercion izq
        if (insertaDato(p->izq, dato)) {
            p->bal++;
            if (p->bal == 1) {
                deltaH = 1;
            } else if (p->bal == 2) {
                if (p->izq->bal == -1) {
                    rotarIzquierda(p->izq);
                }
                rotarDerecha(nodo);
                p = nodo;
            }
        }
    }

    return deltaH;
}

/**
 * @brief metodo de copia profunda del arbol AVL
 * @param p
 * @return el nuevo Árbol (copiado)
 */
template<typename T>
Nodo<T> *AVL<T>::copiaAvl(const Nodo<T> *p) {
    if (!p) {
        return nullptr;
    }

    Nodo<T> *nuevo = new Nodo<T>(p->dato);
    nuevo->bal = p->bal;
    nuevo->izq = copiaAvl(p->izq);
    nuevo->der = copiaAvl(p->der);

    return nuevo;
}

/**
 * @brief Destruccion profunda del Arbol AVL que deseamos
 * @param p
 */
template<typename T>
void AVL<T>::destruyeArbol(Nodo<T> *&p) {
    if (p) {
        destruyeArbol(p->izq);
        destruyeArbol(p->der);
        delete p;
        p= nullptr;
    }
}

/**
 * @brief metodo que nos permite conocer a que dato estamos apuntando de forma recursiva
 * @param p
 * @param dato
 * @return puntero a la direccion del dato
 */
template<typename T>
T *AVL<T>::buscaClave(Nodo<T> *p, const T &dato) const {
    if (p == nullptr) {
        return nullptr;
    }

    if (dato < p->dato) {
        return buscaClave(p->izq, dato);
    }
    if (dato > p->dato) {
        return buscaClave(p->der, dato);
    }
    return &(p->dato);
}

/**
 * @brief Búsqueda de inorden en el AVL
 * @param p
 * @param nivel
 * @param v
 */
template<typename T>
void AVL<T>::inorden(Nodo<T> *p, int nivel, VDinamico<T *> &v) const {
    if (p) {
        inorden(p->izq,nivel + 1, v);
        v.insertar(&(p->dato));
        inorden(p->der,nivel + 1, v);
    }
}

/**
 * @brief metodo de obtencion de altura maxima de la rama que cuelga p
 * @param p
 * @return
 */
template<typename T>
unsigned int AVL<T>::alturaPrivate(Nodo<T> *p) const {
    if (!p) {
        return 0;
    }

    int alturaIzquierda = alturaPrivate(p->izq);
    int alturaDer = alturaPrivate(p->der);

    if (alturaIzquierda > alturaDer) {
        return 1 + alturaIzquierda ;
    }else {
        return 1 + alturaDer;
    }
}

/**
 * @brief recorre el arbol por un intervalo dado
 * @param p
 * @param min
 * @param max
 * @param resultado
 */
template<typename T>
void AVL<T>::buscarRango(Nodo<T> *p, const T &min, const T &max, VDinamico<T *> &resultado) const {
    if (!p) {
        return;
    }
    if (p->dato > min) {
        buscarRango(p->izq, min, max, resultado);
    }
    if (!(p->dato < min) && !(p->dato > max)) {
        resultado.insertar(&(p->dato));
    }
    if (p->dato < max) {
        buscarRango(p->der, min, max, resultado);
    }
}

//METODOS PUBLIC
template<typename T>
AVL<T>::AVL(): raiz(nullptr), tam(0) {

}


template <typename T>
AVL<T>::AVL(const AVL<T>& orig){
    raiz = copiaAvl(orig.raiz);
    tam = orig.tam;
}

template <typename T>
AVL<T>&AVL<T>:: operator=(AVL<T> const& orig) {
    if (this != &orig) {
        destruyeArbol(raiz);
        raiz =copiaAvl(orig.raiz);
        tam = orig.tam;
    }
    return *this;
}

template<typename T>
AVL<T>::~AVL() {
    destruyeArbol(raiz);
}

/**
 * @brief metodo que devuelve la altura
 * @return la altura calculada anteriormente
 */
template<typename T>
unsigned int AVL<T>::altura() const {
    return alturaPrivate(raiz);
}

/**
 * @brief metodo que calcula el tamaño del arbol
 * @return tam
 */
template<typename T>
unsigned int AVL<T>::gettam() const {
    return tam;
}

/**
 * @brief metodo que comprueba si se ha realizado correctamente la inserción
 * @param dato
 * @return true o false
 */
template<typename T>
bool AVL<T>::inserta(const T &dato) {
    int antes = tam;
    insertaDato(raiz, dato);
    return tam > antes;
}

/**
 * @brief busqueda iterativa que devuelve el dato al que apunte p
 * @param dato
 * @return
 */
template<typename T>
T *AVL<T>::buscaIt(const T &dato) const {
    Nodo<T> *p = raiz;
    while (p) {
        if (p->dato == dato) {
            return &(p->dato);
        }
        if (dato < p->dato) {
            p= p->izq;
        } else {
            p= p->der;
        }
    }
    return nullptr;
}

/**
 * @brief busqueda recursiva
 * @param dato
 * @return puntero al dato
 */
template<typename T>
T *AVL<T>::buscaRec(const T &dato) const {
    return buscaClave(raiz,dato);
}

/**
 * @brief metodo que crea un vector Dinamico sobre el cual se nos indique el Rango obtenido
 * @param min
 * @param max
 * @return r
 */
template<typename T>
VDinamico<T *> AVL<T>::buscarRango(const T &min, const T &max) const {
    VDinamico<T *> r;
    buscarRango(raiz,min,max,r);
    return r;
}

/**
 * @brief Metodo que recorre en inorden el arbol para generar el vector dinamico ordenado
 * @return r
 */
template<typename T>
VDinamico<T *> AVL<T>::recorreEnOrden() const {
    VDinamico<T *> r;
    inorden(raiz,0,r);
    return r;
}












#endif //PRACTICA_3_AVL_H