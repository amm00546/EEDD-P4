//
// Created by a_amo on 22/09/2026.
//

#ifndef PRACTICA_3_VDINAMICO_H
#define PRACTICA_3_VDINAMICO_H
#include <format>
#include <iostream>
#include <string>
#include <algorithm>
#include <cmath>
#include <climits>
#include <stdexcept>

//Indicamos que esta clase es un template.
template<class T>

class VDinamico {
private:
    unsigned int _tamfis = 1;    //Tamaño maximo
    unsigned int _tamlog = 0;    //Tamaño real (num. elementos que hay en el vector)
    T *v;   //Vector con la T de template, admite cualquier tipo de dato


    /**
     * @brief: calcula la potencia de 2 igual o superior al tamaño lógico solicitado
     * @param n
     * @return capacidad física calculada
     */
    unsigned int potencia2(unsigned int n)  {
        unsigned int pot = 1;
        while (pot < n) pot *= 2;
        return pot;
    }

    /**
     *@brief: Duplica la capacidad del vector cuando se alcanza el límite físico
     */
    void ampliar()  {
        _tamfis *= 2;

        T* vaux = new T[_tamfis];

        for (unsigned int i = 0; i < _tamlog; i++)
            vaux[i] = v[i];

        delete[]v;
        v = vaux;
    }

    /**
     * @brief: reduce la memoria a la mitad si la ocupación cae por debajo de un tercio
     */

    void disminuye()  {
        if(3*_tamlog < _tamfis && _tamfis > 1) {
            _tamfis = _tamfis / 2;
            T* vaux = new T[_tamfis];
            for (unsigned int i = 0; i < _tamlog; i++) {
                vaux[i] = v[i];
            }
            delete[] v;
            v = vaux;
        }
    }

public:
    VDinamico(); //Inicia tam fisico a 1 y logico a 0. Inicializa v con T[_tamfis] para no tener nullptr y asi reservar espacio para el vector
    VDinamico(unsigned int tamlog, const T& dato);
    VDinamico(const VDinamico<T>& origen);
    VDinamico(const VDinamico<T>& origen, unsigned int posicionInicial, unsigned int numElementos);
    VDinamico& operator=(const VDinamico& origen);
    T& operator[](unsigned pos);
    const T& operator[](unsigned pos) const;
    void insertar(const T& dato, unsigned int pos = UINT_MAX);
    T borrar(unsigned int pos = UINT_MAX);
    void ordenar();
    unsigned int tamlog() const;
    int busquedaDicotomica(const T& dato);
    virtual ~VDinamico();
};

//NOTA: todos los for y bucles tienen "unsigned int i = 0" en vez de int "i = 0" para mantener la consistencia entre la "i" y los atributos de la clase

//Tamaño fisico a la potencia de 2, superior a tamlog

/**
 * @brief: constructor parametrizado del vector dinámico para almacenar datos de tipo T
 * @param tamlog
 * @param dato
 */
template <class T>
VDinamico<T>::VDinamico(unsigned int tamlog, const T& dato)    {
    _tamlog = tamlog;

    _tamfis = potencia2(_tamlog);//std::pow(2, tamlog + 1);

    v = new T[_tamfis];

    for (unsigned int i = 0; i < _tamlog; i++) {
        v[i] = dato;
    }

}

/**
 *@brief: Constructor por defecto con tamanios iniciados a 0 y 1 respectivamente
 *
 */
template <class T>
VDinamico<T>::VDinamico(): _tamfis(1), _tamlog(0) {
    v = new T[_tamfis];
}

/**
 * @brief: Constructor de copia del vector dinamico
 * @param origen
 */
template <class T>
VDinamico<T>::VDinamico(const VDinamico<T>& origen): _tamfis(origen._tamfis), _tamlog(origen._tamlog) {
    v = new T[_tamfis];

    for (unsigned int i = 0; i < _tamlog; i++)
    {
        v[i] = origen.v[i];
    }
}

/**
 * @brief: Constructor de copia parcial
 * @param origen
 * @param posicionInicial
 * @param numElementos
 * @throw std::out_of_range si la posicion inicial mas el numero de elementos superan el tamaño del vector origen
 */
template <class T>
VDinamico<T>::VDinamico(const VDinamico<T>& origen, unsigned int posicionInicial,
                        unsigned int numElementos)
{
    if (posicionInicial + numElementos> origen._tamlog) {
        throw std::out_of_range("ERROR: la posicion inicial y el numero de elementos superan el tamaño del vector origen");
    }
    _tamlog = numElementos;
    _tamfis = potencia2(_tamlog);
    v = new T[_tamfis];
    for (unsigned int i = 0; i < _tamlog; i++) {
        v[i] = origen.v[posicionInicial+i];
    }
}

/**
 * @brief: Operador de asignacion de la clase VDinamico
 * @param origen
 * @return Referencia al objeto actual(*this)
 */
template <class T>
VDinamico<T>& VDinamico<T>::operator=(const VDinamico& origen)   {
    if(this != &origen)  {
        T *vaux = new T[origen._tamfis];
        for (unsigned int i = 0; i< origen._tamlog; i++) {
            vaux[i] = origen.v[i];
        }

        //Operador de asignacion del puntero "v"
        delete[] v;
        v = vaux;
        _tamfis = origen._tamfis;
        _tamlog = origen._tamlog;

    }
    return *this;
}

/**
 * @brief: Operador [] que permite la lectura del vector
 * @param pos
 * @return El dato de la posicion del vector a la que queremos acceder
 */
template <class T>
T& VDinamico<T>::operator[](unsigned pos)
{
    if (pos >= _tamlog)
        throw std::out_of_range("ERROR: [VDinamico.h -> operator[]] la posicion no es valida, es mayor que el numero real de datos (tamlog).");

    return v[pos];
}

/**
 * @brief: Método que consiste en insertar un nuevo dato en medio del vector
 * @param dato
 * @param pos
 * @throw std::out_of_range Si la posición es mayor que el tamaño
 */
template <class T>
void VDinamico<T>::insertar(const T& dato, unsigned int pos)   {
    if (pos == UINT_MAX) {
        pos = _tamlog;
    }

    if (pos > _tamlog) {
        throw std::out_of_range("Error: [VDinamico.h -> insertar] posicion no valida. ");
    }
    if (_tamlog >= _tamfis) {
        ampliar();
    }


    for (unsigned int i = _tamlog; i > pos; i--) {
        v[i] = v[i - 1];
    }

    v[pos] = dato;
    _tamlog++;
}

/**
 * @brief: Metodo de borrado en el vector dinamico
 * @param pos
 * @throw std::out_of_range Si el tamaño del vector es 0
 * @throw std::out_of_range Si la posición a la que intentamos acceder es mayormo igual que el tamaño del vector
 * @return borrado
 *
 */
template <class T>
T VDinamico<T>::borrar(unsigned int pos)   {
    if (_tamlog == 0) {
        throw std::out_of_range("ERROR: no se puede borrar un vector vacio");
    }
    if (pos == UINT_MAX)    {
        pos = _tamlog - 1;
    }
    if (pos >= _tamlog){
        throw std::out_of_range("ERROR: [VDinamico.h -> borrar] posicion invalida, no hay tantos datos en el vector");
    }

    T borrado = v[pos];

    for (unsigned int i = pos; i < _tamlog - 1; i++)
    {
        v[i] = v[i + 1];
    }

    --_tamlog;

    disminuye();

    return borrado;
}


/**
 * @brief: metodo para ordenar el vector dinamico usando la libreria algorithm
 */
template <class T>
void VDinamico<T>::ordenar()
{
    std::sort(v, v + _tamlog);
}

/**
 * @brief: Metodo para obtener el tamanio logico de un vector
 * @return _tamlog
 */
template <class T>
unsigned int VDinamico<T>::tamlog() const
{
    return _tamlog;
}


/**
 * @brief: metodo de una busqueda binaria en el vector que ha sido ordenado previamente
 * @param dato
 * @return posicion del dato o -1 si no se encuentra
 */
template <class T>
int VDinamico<T>::busquedaDicotomica(const T& dato)
{
    int inf = 0;
    int sup = static_cast<int>(_tamlog ) - 1;

    while (inf <= sup)
    {
        int medio = (inf + sup) / 2;

        if (v[medio] == dato) {
            return medio;
        }
        else if (v[medio] < dato) {
            inf = medio + 1;
        }
        else {
            sup = medio - 1;
        }
    }

    return -1;  // no encontrado
}

/**
 * @brief: Destructor de la clase VDinamico
 */
template <class T>
VDinamico<T>::~VDinamico()
{
    delete[] v;
}

template <class T>
const T& VDinamico<T>::operator[](unsigned pos) const {
    if (pos >= _tamlog) {
        throw std::out_of_range("ERROR: [VDinamico.h -> operator[] const] posicion no valida.");
    }
    return v[pos];
}

#endif //PRACTICA_3_VDINAMICO_H