//
// Created by Pablo on 04/10/2026.
//

#ifndef PRACTICA_3_LISTADENLAZADA_H
#define PRACTICA_3_LISTADENLAZADA_H

#include <stdexcept>

template <class T>
class ListaDEnlazada {
private:
    //Clase Nodo en private
    class Nodo {
    public:
        T dato;
        Nodo *sig = nullptr;
        Nodo *ant = nullptr;

        Nodo(const T& dato, Nodo* ant = nullptr, Nodo* sig = nullptr);

    };

    Nodo* cabecera = nullptr;
    Nodo* cola = nullptr;
    unsigned int _tam = 0;

public:
    //Clase Iterador en el interior como public para poder explicarse cómo nos desplazamos en la Lista
    class Iterador {
    private:
        Nodo* nodo;
        friend class ListaDEnlazada; //Permite a la lista acceder al nodo interno
    public:
        Iterador();
        Iterador(Nodo* p);
        T& operator*() const;
        T& getdato() const { return operator*(); }
        Iterador& operator++();
        Iterador& operator--();
        bool operator==(const Iterador& orig) const;
        bool operator!=(const Iterador& orig) const;

        bool fin() const { return nodo == nullptr; }
        void avanza() { operator++(); }

    };

    void liberarMemoria();
    ListaDEnlazada();
    ListaDEnlazada(const ListaDEnlazada<T>& orig);
    ListaDEnlazada<T> &operator=(const ListaDEnlazada& orig);

    Iterador iterador() const;
    Iterador iterador();

    T& inicio();
    T& fin();
    void insertaInicio(const T& dato);
    void insertaFin(const T& dato);

    void inserta(Iterador &i, const T &dato);
    void borra(Iterador &i);


    void borraInicio();
    void borraFinal();
    void borraFin() { borraFinal(); }

    int tamLista() const;
    ListaDEnlazada<T> concatena(const ListaDEnlazada& l) const;
    ListaDEnlazada<T> operator+(const ListaDEnlazada& l) const;


    ~ListaDEnlazada();




};

//DE LA CLASE NODO
template <typename T>
ListaDEnlazada<T>::Nodo::Nodo(const T& dato, Nodo* ant , Nodo* sig ): dato(dato), sig(sig), ant(ant) {
}

/**
 * @brief metodo privado de la clase Nodo que consiste en liberar aquella memoria que no vamos a usar para la lista
 */
template<class T>
void ListaDEnlazada<T>::liberarMemoria() {
    while (cabecera) {
        Nodo* aux = cabecera;
        cabecera = cabecera->sig;
        delete aux;
    }
    cola = nullptr;
    _tam = 0;
}

//DE LA CLASE ITERADOR
template <typename T>
ListaDEnlazada<T>::Iterador::Iterador(): nodo(nullptr) {

}

template <typename T>
ListaDEnlazada<T>::Iterador::Iterador(Nodo* p): nodo(p) {

}

/**
 * @brief Operador * perteneciente a Iterador
 * @return el dato hacia el que apunta el nodo
 */
template<class T>
T &ListaDEnlazada<T>::Iterador::operator*() const {
    if (!nodo) {
        throw std::invalid_argument("Nodo invalido");
    }
    return nodo->dato;
}

/**
 * @brief Operador ++ de la clase Iterador
 * @return puntero this que apunta al siguiente elemento de la lista
 */
template<typename T>
typename ListaDEnlazada<T>::Iterador& ListaDEnlazada<T>::Iterador::operator++() {
    if (nodo) {
        nodo = nodo->sig;
    }else {
        throw std::invalid_argument("Nodo invalido");
    }
    return *this;
}

/**
 * @brief Operador -- de la clase Iterador
 * @return puntero this que apunta al  elemento anterior de la lista
 */
template<typename T>
typename ListaDEnlazada<T>::Iterador &ListaDEnlazada<T>::Iterador::operator--() {
    if (nodo) {
        nodo = nodo->ant;
    }else {
        throw std::invalid_argument("Nodo invalido");
    }
    return *this;
}

/**
 * Operadores == y != de la clase Iterador
 * @param orig
 * @return copia del nodo
 */

template<class T>
bool ListaDEnlazada<T>::Iterador::operator==(const Iterador &orig) const {
    return nodo == orig.nodo;
}

template<class T>
bool ListaDEnlazada<T>::Iterador::operator!=(const Iterador &orig) const {
    return nodo != orig.nodo;
}

//DE LA CLASE LISTADENLAZADA

//CONSTRUCTORES, OPERADOR = Y DESTRUCTOR

template<class T>
ListaDEnlazada<T>::ListaDEnlazada() : cabecera(nullptr), cola(nullptr), _tam(0) {

}

/**
 * @brief Constructor de copia para la lista
 * @param orig
 */
template<class T>
ListaDEnlazada<T>::ListaDEnlazada(const ListaDEnlazada &orig): cabecera(nullptr), cola(nullptr), _tam(0) {
    Nodo* aux = orig.cabecera;
    while (aux) {
        insertaFin(aux->dato);
        aux = aux->sig;
    }
}

/**
 * @brief Operator = para la clase ListaDEnlazada
 * @param orig
 * @return
 */
template<typename T>
ListaDEnlazada<T> &ListaDEnlazada<T>::operator=(const ListaDEnlazada &orig) {
    if (this != &orig) {
        liberarMemoria();
        Nodo* aux = orig.cabecera;
        while (aux) {
            insertaFin(aux->dato);
            aux = aux->sig;
        }
    }
    return *this;
}

/**
 * @brief Destructor de la clase (lista)
 */
template<typename T>
ListaDEnlazada<T>::~ListaDEnlazada() {
    liberarMemoria();
}

//OBSERVADORES (ITERADOR)
/**
 * @brief metodo que situa la iteracion de los elementos de la lista
 * @return puntero que apunta a la cabecera de la lista
 */
template<class T>
typename ListaDEnlazada<T>::Iterador ListaDEnlazada<T>::iterador() const {
    return Iterador(cabecera);
}

template<class T>
typename ListaDEnlazada<T>::Iterador ListaDEnlazada<T>::iterador() {
    return Iterador(cabecera);
}

/**
 * @brief metodo que consiste en acceder al inicio de la lista
 * @return dato al que apunta la cabecera (inicio)
 */
template<typename T>
T& ListaDEnlazada<T>::inicio() {
    if (!cabecera) {
        throw std::domain_error("Acceso al inicio en una lista vacia");
    }
    return cabecera->dato;
}

/**
 * @brief metodo que consiste en acceder al final de la lista
 * @return dato al que apunta la cola (final)
 */
template<class T>
T &ListaDEnlazada<T>::fin() {
    if (!cola) {
        throw std::domain_error("Acceso al final en una lista vacia");
    }
    return cola->dato;
}

/**
 * @brief Metodo que nos permite conocer el tamanio de la lista actual
 * @return tamanio de la lista
 */
template<class T>
int ListaDEnlazada<T>::tamLista() const {
    return _tam;
}

//INSERCIONES Y BORRADOS
/**
 * @brief metodo de insercion por el inicio de una lista
 * @param dato
 */
template<class T>
void ListaDEnlazada<T>::insertaInicio(const T &dato) {
    Nodo* nuevo = new Nodo(dato, nullptr, cabecera);
    if (cabecera) {
        cabecera->ant = nuevo;
    }else {
        cola = nuevo;
    }
    cabecera = nuevo;
    _tam++;
}

/**
 * @brief Metodo de borrado al inicio de la lista
 */
template<class T>
void ListaDEnlazada<T>::borraInicio() {
    if (!cabecera) {
        throw std::domain_error("No se puede borrar un elemento de una lista vacía");
    }
    Nodo* borrado = cabecera;
    cabecera = cabecera->sig;
    if (cabecera) {
        cabecera->ant = nullptr;
    }else {
        cola = nullptr;
    }
    delete borrado;
    _tam--;
}

/**
 * @brief Metodo de inserción al final de la lista
 * @param dato
 */
template<class T>
void ListaDEnlazada<T>::insertaFin(const T &dato) {
    Nodo* nuevo = new Nodo(dato, cola, nullptr);
    if (cola) {
        cola->sig = nuevo;
    }else {
        cabecera = nuevo;
    }
    cola = nuevo;
    _tam++;
}

/**
 * @brief metodo de borrado del elemento final de la lista
 */
template<class T>
void ListaDEnlazada<T>::borraFinal() {
    if (!cola) {
        throw std::domain_error("No se puede eliminar un elemento final de una lista vacia");
    }
    Nodo* borradof = cola;
    cola = cola->ant;
    if (cola) {
        cola->sig = nullptr; // Se reengancha el puntero siguiente de la cola
    }else {
        cabecera = nullptr;
    }
    delete borradof;
    _tam--;
}

/**
 * @brief Metodo de insercion por el medio de una lista
 * @param i
 * @param dato
 */
template<class T>
void ListaDEnlazada<T>::inserta(Iterador &i, const T &dato) {
    if (!i.nodo) {
        insertaFin(dato);
        return;
    }
    if (i.nodo == cabecera) {
        insertaInicio(dato);
        return;
    }

    Nodo* pivote = i.nodo;
    Nodo* previo = pivote->ant;
    Nodo* nuevo = new Nodo(dato, previo, pivote);

    previo->sig = nuevo;
    pivote->ant = nuevo;
    _tam++;
}

/**
 * @brief metodo de borrado por el medio de la lista
 * @param i
 */
template<typename T>
void ListaDEnlazada<T>::borra(Iterador& i) {
    Nodo* p = i.nodo;
    if (!p) {
        throw std::invalid_argument("Iterador no valido para borrado");
    }
    i.nodo = p->sig;

    if (p == cabecera) {
        borraInicio();
        return;
    }
    if (p == cola) {
        borraFinal();
        return;
    }
    Nodo* izq = p->ant;
    Nodo* der = p->sig;
    izq->sig = der;
    der->ant = izq;

    delete p;
    _tam--;
}

//CONCATENACIÓN
/**
 * @brief metodo de concatenacion de listas
 * @param l
 * @return resul (lista nueva con la concatenacion de las listas previas)
 */
template<typename T>
ListaDEnlazada<T> ListaDEnlazada<T>::concatena(const ListaDEnlazada &l) const {
    ListaDEnlazada<T> resul(*this);
    Nodo* aux = l.cabecera;

    while (aux) {
        resul.insertaFin(aux->dato);
        aux = aux->sig;
    }

    return resul;
}

/**
 * @brief sobrecarga del operator + para que se efectue la concatenacion de listas
 * @param l
 * @return el metodo concatena, es decir, la lista concatenada
 */
template<class T>
ListaDEnlazada<T> ListaDEnlazada<T>::operator+(const ListaDEnlazada &l) const {
    return concatena(l);
}

#endif //PRACTICA_3_LISTADENLAZADA_H