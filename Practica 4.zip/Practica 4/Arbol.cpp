//
// Created by Pablo on 19/10/2026.
//

#include "Arbol.h"
#include "Especie.h"


Arbol::Arbol(): assetnum(""), numParque(0), numDistrito(0), nombreDistrito(""),
                numBarrio(0), nombreBarrio(""), x(0), y(0), perimetro(0),altura(0), especie(nullptr), isInto(nullptr) {

}

Arbol::Arbol(const std::string& assetnum): assetnum(assetnum), numParque(0), numDistrito(0), nombreDistrito(""),
      numBarrio(0), nombreBarrio(""), x(0), y(0),
      perimetro(0), altura(0), especie(nullptr), isInto(nullptr){}

Arbol::Arbol(const std::string& assetnum, int numParque, int numDistrito,
             const std::string& nombreDistrito, int numBarrio,
             const std::string& nombreBarrio, double x, double y,
             float perimetro, float altura):
    assetnum(assetnum), numParque(numParque), numDistrito(numDistrito),
    nombreDistrito(nombreDistrito), numBarrio(numBarrio),
    nombreBarrio(nombreBarrio), x(x), y(y),
    perimetro(perimetro), altura(altura), especie(nullptr), isInto(nullptr) {}

void Arbol::setEspecie(Especie* e) {
    especie = e;
}

Especie* Arbol::getEspecie() const {
    return this->especie;
}

std::string Arbol::getCodEspecie() const {
    if (especie == nullptr) {
        return "";
    }
    return this->especie->getcodigoEspecie();
}
std::string Arbol::getTipoEspecie() const {
    if (especie == nullptr) {
        return "";
    }
    return this->especie->gettipo_planta();
}
std::string Arbol::getNbreComun() const {

    if (especie == nullptr) {
        return "";
    }
    return this->especie->getnombre_comun();
}
std::string Arbol::getNbreCientifico() const {
    if (especie == nullptr) {
        return "";
    }
    return this->especie->getnombre_cientifico();
}

std::string Arbol::getAssetnum() const {
    return this->assetnum;
}

int Arbol::getNumParque() const {
    return this->numParque;
}

int Arbol::getNumDistrito() const {
    return this->numDistrito;
}

std::string Arbol::getNombreDistrito() const {
    return this->nombreDistrito;
}

int Arbol::getNumBarrio() const {
    return this->numBarrio;
}

std::string Arbol::getNombreBarrio() const {
    return this->nombreBarrio;
}

double Arbol::getX() const {
    return this->x;
}

double Arbol::getY() const {
    return this->y;
}

float Arbol::getAltura() const {
    return this->altura;
}

float Arbol::getPerimetro() const {
    return this->perimetro;
}

bool Arbol::operator<(const Arbol& otro) const {
    return assetnum <  otro.assetnum;
}

bool Arbol::operator>(const Arbol& otro) const {
    return assetnum >  otro.assetnum;
}

bool Arbol::operator==(const Arbol& otro) const {
    return assetnum == otro.assetnum;
}

bool Arbol::operator!=(const Arbol& otro) const {
    return assetnum != otro.assetnum;
}

void Arbol::setParque(Parque* p) {
    isInto = p;
}
Parque* Arbol::getParque() const {
    return this->isInto;
}