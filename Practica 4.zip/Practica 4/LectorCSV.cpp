#include "LectorCSV.h"
#include <functional>
#include "Arbol.h"
#include <fstream>
#include <iostream>
#include "Especie.h"
#include <string>
#include <vector>
#include <list>

/**
 * @brief Carga el fichero CSV indicado, mostrando cada especie por pantalla.
 *
 * Cada línea se analiza y, si tiene el número de campos esperado, se
 * construye una Especie que se almacena en el VDinamico
 * Las filas con un número de campos
 * distinto del esperado se descartan (ver filasDescartadas()).
 *
 * @param rutaFichero Ruta del fichero CSV a leer.
 * @return true si el fichero se ha podido abrir, false en caso contrario.
 */
bool LectorCSV::cargar(std::vector<Especie> &vector, const std::string& rutaFichero) {
    filasDescartadas_ = 0;

    std::ifstream fichero(rutaFichero);
    if (!fichero.is_open()) {
        return false;
    }

    std::string linea;
    if (std::getline(fichero, linea)) {
        eliminarBOM(linea);
    }

    //Declaradas fuera del bucle por eficiencia
    std::string codigo, nombreComun, nombreCientifico, tipoPlanta;
    while (std::getline(fichero, linea)) {
        if (linea.empty()) {
            continue;
        }

        if (contarCampos(linea) != 4) {
            ++filasDescartadas_;
            continue;
        }

        codigo = extraerCampo(linea, 0);
        nombreComun = extraerCampo(linea, 1);
        nombreCientifico = extraerCampo(linea, 2);
        tipoPlanta = extraerCampo(linea, 3);
        vector.push_back(Especie(codigo, nombreComun, nombreCientifico,tipoPlanta));

    }
    numeroEspecies_= vector.size();
    return true;
}

/**
 * @brief Número de especies leídas correctamente.
 * @return Cantidad de especies mostradas durante la última llamada a cargar().
 */
std::size_t LectorCSV::numeroEspecies() const {
    return numeroEspecies_;
}

/**
 * @brief Número de filas descartadas por no tener el número de campos esperado.
 * @return Cantidad de filas descartadas durante la última llamada a cargar().
 */
std::size_t LectorCSV::filasDescartadas() const {
    return filasDescartadas_;
}

/**
 * @brief Elimina el BOM UTF-8 (0xEF 0xBB 0xBF) al inicio de la línea, si existe.
 * @param linea Línea a modificar in-place.
 */
void LectorCSV::eliminarBOM(std::string& linea) {
    static const char bom[3] = { static_cast<char>(0xEF), static_cast<char>(0xBB), static_cast<char>(0xBF) };
    if (linea.size() >= 3 && linea[0] == bom[0] && linea[1] == bom[1] && linea[2] == bom[2]) {
        linea.erase(0, 3);
    }
}

/**
 * @brief Muestra por pantalla los datos de una especie.
 * @param especie Especie a mostrar.
 */
void LectorCSV::mostrarEspecie(const Especie& especie) {
    std::cout << " - [" << especie.getcodigoEspecie() << "] " << especie.getnombre_comun()
              << " (" << especie.getnombre_cientifico() << ") - "
              << especie.gettipo_planta() << "\n";
}

/**
 * @brief Carga el fichero CSV de parques en una lista doblemente enlazada
 * @param lista Lista donde se insertan los parques leidos
 * @param rutaFichero Ruta del fichero CSV de parques
 * @return true Si filasDescartadas() contiene el numero de filas descartadas en esta llamda
 */
bool LectorCSV::cargarParques(std::list<Parque>& lista, const std::string& rutaFichero) {
    filasDescartadas_ = 0;

    std::ifstream fichero(rutaFichero);
    if (!fichero.is_open()) {
        return false;
    }

    std::string linea;
    if (std::getline(fichero, linea)) {
        eliminarBOM(linea);                     // cabecera
    }

    while (std::getline(fichero, linea)) {
        if (linea.empty()) continue;
        if (contarCampos(linea) != 2) {
            filasDescartadas_++;
            continue;
        }

        int codigo;
        try {
            codigo = std::stoi(extraerCampo(linea, 0));
        } catch (const std::exception&) {       // codigo no numerico
            filasDescartadas_++;
            continue;
        }

        Parque parque(codigo, extraerCampo(linea, 1));
        lista.push_back(parque);               // en orden de lectura
    }
    return true;
}
std::size_t LectorCSV::contarCampos(const std::string& linea, char sep) {
    std::size_t numCampos = 1;
    bool dentroComillas = false;
    const std::size_t n = linea.size();

    for (std::size_t i = 0; i < n; ) {
        const char c = linea[i];

        if (dentroComillas) {
            if (c == '"') {
                if (i + 1 < n && linea[i + 1] == '"') {
                    i += 2;
                } else {
                    dentroComillas = false;
                    ++i;
                }
            } else {
                ++i;
            }
        } else if (c == '"') {
            dentroComillas = true;
            ++i;
        } else if (c == sep) {          // antes: c == ','
            ++numCampos;
            ++i;
        } else {
            ++i;
        }
    }

    return numCampos;
}

std::string LectorCSV::extraerCampo(const std::string& linea, std::size_t indiceObjetivo, char sep) {
    std::string campo;
    std::size_t indiceActual = 0;
    bool dentroComillas = false;
    const std::size_t n = linea.size();

    for (std::size_t i = 0; i < n; ) {
        const char c = linea[i];

        if (dentroComillas) {
            if (c == '"') {
                if (i + 1 < n && linea[i + 1] == '"') {
                    if (indiceActual == indiceObjetivo) {
                        campo += '"';
                    }
                    i += 2;
                } else {
                    dentroComillas = false;
                    ++i;
                }
            } else {
                if (indiceActual == indiceObjetivo) {
                    campo += c;
                }
                ++i;
            }
        } else if (c == '"') {
            dentroComillas = true;
            ++i;
        } else if (c == sep) {          // antes: c == ','
            if (indiceActual == indiceObjetivo) {
                return campo;
            }
            ++indiceActual;
            ++i;
        } else {
            if (indiceActual == indiceObjetivo) {
                campo += c;
            }
            ++i;
        }
    }

    return campo;
}

static float aFloat(std::string& texto) {          // "2,5" -> 2.5 ; "" -> 0
    if (texto.empty()) return 0.0f;
    for (std::size_t i = 0; i < texto.size(); ++i) if (texto[i] == ',') texto[i] = '.';
    return std::stof(texto);
}

bool LectorCSV::cargarArboles(const std::string& rutaFichero,
                              const std::function<void(Arbol&, const std::string&)>& alLeer) {
    filasDescartadas_ = 0;
    std::ifstream fichero(rutaFichero);
    if (!fichero.is_open()) return false;

    std::string linea;
    if (std::getline(fichero, linea)) eliminarBOM(linea);       // cabecera

    const std::size_t NUM_CAMPOS = 12;
    std::string campos[NUM_CAMPOS];
    Arbol arbol;

    while (std::getline(fichero, linea)) {
        if (!linea.empty() && linea.back() == '\r') linea.pop_back();
        if (linea.empty()) continue;

        std::size_t n = 0, ini = 0;                             // troceo en una sola pasada
        while (n < NUM_CAMPOS - 1) {
            std::size_t fin = linea.find(';', ini);
            if (fin == std::string::npos) break;
            campos[n++].assign(linea, ini, fin - ini);
            ini = fin + 1;
        }
        if (n != NUM_CAMPOS - 1 || linea.find(';', ini) != std::string::npos) { ++filasDescartadas_; continue; }
        campos[n].assign(linea, ini, std::string::npos);

        bool valida = true;
        try {
            arbol = Arbol(campos[0], std::stoi(campos[1]), std::stoi(campos[2]), campos[3],
                          std::stoi(campos[4]), campos[5], std::stod(campos[6]), std::stod(campos[7]),
                          aFloat(campos[10]), aFloat(campos[11]));
        } catch (const std::exception&) { valida = false; }
        if (!valida) { ++filasDescartadas_; continue; }

        alLeer(arbol, campos[8]);                               // campos[8] = CODIGO_ESPECIE
    }
    return true;
}