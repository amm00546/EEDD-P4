//
// Created by a_amo on 22/09/2026.
//

#ifndef PRACTICA_3_ESPECIE_H
#define PRACTICA_3_ESPECIE_H
#include <string>

//enum Tipo Planta UML
enum class TipoPlanta {
    ARBUSTO,
    CONIFERA,
    PALMACEA,
    HERB_PERENNES,
    FRONDOSA,
    TAPIZANTE_TREPADORA,
    CACTACEA_SUCULENTA,
    SUBTROPICAL_TROPICAL,
    HERB_ANUAL,
    HERB_ANUALES,
    DESCONOCIDO
};

// Funciones auxiliares para la conversion CSV y visualizacion
TipoPlanta stringToTipoPlanta(const std::string& str);
std::string tipoPlantaToString(TipoPlanta tipo);


class Especie {
private:
    std::string codigoEspecie;
    std::string nombreComun;
    std::string nombreCientifico;
    std::string tipoPlanta;
public:
    //Constructor por defecto
    Especie();
    //Constructor parametrizado
    Especie(const std::string& codigo, const std::string& nComun, const std::string& nCientifico, const std::string& tPlanta);
    // Constructor copia
    Especie(const Especie& orig);


    //Getters
    std::string getcodigoEspecie() const;
    std::string getnombre_comun() const;
    std::string getnombre_cientifico() const;
    std::string gettipo_planta() const;

    //Setters
    void set_codigo_especie(const std::string& c);
    void set_nombre_comun(const std::string& n);
    void set_nombre_cientifico(const std::string& n);
    void set_tipo_planta(const std::string& t);

    //Operador de asignación
    Especie& operator=(const Especie& orig);
    //Operadores para la ordenación
    bool operator<(const Especie& orig) const;
    bool operator==(const Especie& orig) const;


    void mostrarEspecie() const;


};


#endif //PRACTICA_3_ESPECIE_H