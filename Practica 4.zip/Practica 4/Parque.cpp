//
// Created by a_amo on 07/10/2026.
//

#include "Parque.h"
#include <string>
#include <stdexcept>
#include "Especie.h"


//Constructor por defecto
Parque::Parque():cod_parque(0),nbre_parque(""){

}
//Constructor parametrizado
Parque::Parque(int codigo, const std::string& nParque):cod_parque(codigo), nbre_parque(nParque) {

}
// Constructor copia
Parque::Parque(const Parque& orig) {
    this->cod_parque = orig.cod_parque;
    this->nbre_parque = orig.nbre_parque;
    this->contains = orig.contains;

}


//Getters
int Parque::get_codigo_parque() const {
    return this->cod_parque;
}

const std::string& Parque::get_nombre_parque() const {
    return this->nbre_parque;
}


//Setters
void Parque::set_codigo_parque(int c) {
    this->cod_parque = c;
}
void Parque::set_nombre_parque(const std::string& n) {
    this->nbre_parque = n;
}

//Operador de asignación
Parque& Parque::operator=(const Parque& orig) {
    if (this!= &orig) {
        this->cod_parque = orig.cod_parque;
        this->nbre_parque = orig.nbre_parque;
        this->contains = orig.contains;
    }
    return *this;

}


//Operadores para la ordenación
bool Parque::operator<(const Parque& orig) const {
    return this->cod_parque < orig.cod_parque;
}
bool Parque::operator==(const Parque& orig) const {
    return this->cod_parque == orig.cod_parque;
}


bool Parque::existeNbreCom(const std::string& ncomun) const{
    for (unsigned int i = 0; i < contains.size(); i++) {
        if (contains[i]->getNbreComun() == ncomun) {
            return true;
        }
    }
    return false;

}

/**
 * @brief metodo de insercion de arboles en el parque
 * @param arb
 */
void Parque::insertarArbol(Arbol *arb) {
    if (!arb) {
        throw std::invalid_argument("No se puede insertar un arbol nulo");
    }

    this->contains.push_back(arb);
}

/**
 * @brief metodo para hallar el arbol mas alto
 * @return mayor
 */
Arbol* Parque::arbolMasAlto() const {
    if (contains.size() == 0) {
        return nullptr;
    }
    Arbol* mayor = contains[0];
    for (unsigned int i = 1; i < contains.size(); i++) {
        if (contains[i]->getAltura() > mayor->getAltura()) {
            mayor = contains[i];
        }
    }
    return mayor;
}

/**
 * @brief metodo de contar especies distintas en el AVL
 * @return tamaño del vector de string nuevo creado para anotar las especies diferentes por su codEsp
 */
int Parque::contarEspecies() const {
    std::set<Especie*> vistas;
    for (int i = 0; i < contains.size(); i++) {
        if (contains[i]->getEspecie() != nullptr) {
            vistas.insert(contains[i]->getEspecie());
        }
    }
    return vistas.size();
}

/**
 * @brief metodo para contar los diferentes tipos de arboles que hay
 * @return
 */
int Parque::contarTipos() const {
    std::set<std::string> tipos;
    for (int i = 0; i < contains.size(); i++) {
        const std::string& t = contains[i]->getTipoEspecie();
        if (!t.empty()) {
            tipos.insert(t);
        }
    }
    return tipos.size();
}

const std::vector<Arbol*>& Parque::getArboles() const {
    return this->contains;
}

Especie* Parque::especieMasComun() const {
    std::map<Especie*, int> frecuencia;
    Especie *mejor = nullptr;
    int max = 0;
    for (int i = 0; i < contains.size(); i++) {
        Especie* e = contains[i]->getEspecie();
        if (e!= nullptr) {
            frecuencia[e]++;
            if (frecuencia[e] > max) {
                max = frecuencia[e];
                mejor = e;
            }
        }
    }

    return mejor;
}