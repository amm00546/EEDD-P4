//
// Created by a_amo on 07/10/2026.
//

#include "ControlParques.h"
#include "LectorCSV.h"
#include <stdexcept>
#include <algorithm>
ControlParques::ControlParques(const std::string& rutaEspecies, const std::string& rutaParques, const std::string& rutaArboles){
    LectorCSV lector;

    if (!lector.cargar(especies, rutaEspecies)) {
        throw std::runtime_error("ControlParques: No se pudo abrir "+ rutaEspecies);
    }

    std::sort(especies.begin(), especies.end());
    if(!lector.cargarParques(parques, rutaParques)) {
        throw std::runtime_error("ControlParques: No se pudo abrir "+ rutaParques);
    }

    bool ok = lector.cargarArboles(rutaArboles, [this](const Arbol& leido, const std::string& codEspecie) {
        std::pair<std::map<std::string, Arbol>::iterator, bool> res =
            trees.insert(std::make_pair(leido.getAssetnum(), leido));
        if (!res.second) {
            return;                         // assetnum repetido: no se inserta
        }

        Arbol* a = &(res.first->second);    // puntero al arbol DENTRO del map
        a->setEspecie(buscarEspecieCodigo(codEspecie));

        Parque* p = buscarParqueCodigo(a->getNumParque());
        if (p != nullptr) {
            p->insertarArbol(a);            // Parque::contains
            a->setParque(p);                // Arbol::isInto
        }

        if (a->getEspecie() != nullptr) {
            treeName.insert(std::make_pair(a->getNbreComun(), a));
        }
    });

    if (!ok) {
        throw std::runtime_error("ControlParques: no se pudo abrir " + rutaArboles);
    }
}

std::vector<Especie>& ControlParques::get_especies() {
    return this->especies;
}

std::list<Parque>& ControlParques::get_parques() {
    return this->parques;
}

int ControlParques::contarEspecieParque(const std::string& nComun) {
    if (nComun.empty()) {
        throw std::invalid_argument("Nombre comun vacio");

    }
    return listarParquesArbol(nComun).size();
}

std::vector<Especie*> ControlParques::listadoEspeciesSubNbre(const std::string& cadena) {
    std::vector<Especie*> listado;
    for (unsigned int i = 0; i<especies.size(); i++) {
        const std::string& nombreCientifico = especies[i].getnombre_cientifico();
        if (nombreCientifico.find(cadena)!= std::string::npos) {
            listado.push_back(&especies[i]);
        }
    }
    return listado;
}





Parque* ControlParques::buscarParque(const std::string& nombreParque) {
    for (std::list<Parque>::iterator it = parques.begin(); it != parques.end(); ++it) {
        if (it->get_nombre_parque() == nombreParque) {
            return &(*it);
        }
    }
    return nullptr;
}




//METODOS PRACTICA 3
std::vector<Arbol *> ControlParques::listaArbParque(const std::string &asNum) {
    if (asNum.empty()) {
        throw std::invalid_argument("cadena asNum no valida");
    }
    Parque* parque = buscarParque(asNum);
    if (parque) {
        return parque->getArboles();
    }
    return std::vector <Arbol *>();
}

/**
 * @brief Metodo para buscar arboles de acuerdo con su clave
 * @param asNum
 * @return puntero que que apunra al arbol que queremos encontrar
 */
Arbol* ControlParques::buscarArbol(const std::string& asNum) {
    std::map<std::string, Arbol>::iterator it = trees.find(asNum);
    if (it == trees.end()) {
        return nullptr;
    }
    return &(it->second);
}

Arbol *ControlParques::arbolMasAlto() {
    if (trees.empty()) {
        throw std::runtime_error("No hay arboles cargados");
    }
    std::map<std::string, Arbol>::iterator it = trees.begin();
    Arbol* aMasAlto = &it->second;
    ++it;
    while (it != trees.end()) {
        if (it->second.getAltura()> aMasAlto->getAltura()) {
            aMasAlto = &(it->second);
        }
        ++it;
    }

    return aMasAlto;
}

int ControlParques::contarTipos() const {
    std::set<std::string> tiposDistintos;
    for (std::map<std::string, Arbol>::const_iterator it = trees.begin(); it!= trees.end();++it) {
        if (it->second.getTipoEspecie().empty()) {
            tiposDistintos.insert(it->second.getTipoEspecie());
        }
    }
    return tiposDistintos.size();
}


/**
 * @brief metodo de contar las especies distintas del Parque
 * @param nbreParque
 * @return  donde apunta el iterador
 */
int ControlParques::contarEspecies(const std::string &nbreParque) const {
    if (nbreParque.empty()) {
        throw std::invalid_argument("Nombre de parque vacio");
    }
    for (std::list<Parque>::const_iterator it = parques.begin(); it != parques.end(); ++it) {
        if (it->get_nombre_parque() == nbreParque) {
            return it->contarEspecies();
        }
    }
    return 0;
}

//PAREJAS
/**
 * @brief busca un parque por su codigo
 * @return puntero al parque dentro de la lista, o nullptr si no existe
 */
Parque* ControlParques::buscarParqueCodigo(int cod) {
    for (std::list<Parque>::iterator it = parques.begin(); it != parques.end(); ++it) {
        if (it->get_codigo_parque() == cod) {
            return &(*it);
        }
    }
    return nullptr;
}

/**
 * @brief busca una especie por su codigo (busqueda dicotomica, el vector esta ordenado)
 * @return puntero a la especie dentro del vector, o nullptr si no existe
 */
Especie* ControlParques::buscarEspecieCodigo(const std::string& cod) {
    std::vector<Especie>::iterator it =
        std::lower_bound(especies.begin(), especies.end(), Especie(cod, "", "", ""));
    if (it != especies.end() && it->getcodigoEspecie() == cod) {
        return &(*it);
    }
    return nullptr;
}

unsigned int ControlParques::numArboles() const {
    return trees.size();
}


std::set<Parque*> ControlParques::listarParquesArbol(const std::string& nombreComun) {
    std::set<Parque*> resultado;
    std::pair<std::multimap<std::string, Arbol*>::iterator,
              std::multimap<std::string, Arbol*>::iterator> rango = treeName.equal_range(nombreComun);
    for (std::multimap<std::string, Arbol*>::iterator it = rango.first; it != rango.second; ++it) {
        Parque* p = it->second->getParque();
        if (p != nullptr) {
            resultado.insert(p);            // el set evita parques repetidos
        }
    }
    return resultado;
}

std::vector<Arbol*> ControlParques::buscarArbolNcomun(const std::string& nombreComun) {
    std::vector<Arbol*> resultado;
    std::pair<std::multimap<std::string, Arbol*>::iterator,
              std::multimap<std::string, Arbol*>::iterator> rango = treeName.equal_range(nombreComun);
    for (std::multimap<std::string, Arbol*>::iterator it = rango.first; it != rango.second; ++it) {
        resultado.push_back(it->second);
    }
    return resultado;
}


std::vector<Arbol*> ControlParques::buscarArbolNcomunComienzo(const std::string& comienzo) {
    if (comienzo.empty()) {
        throw std::invalid_argument("Nombre de comienzo vacio");
    }
    std::vector<Arbol*> resultado;
    std::multimap<std::string, Arbol*>::iterator it = treeName.lower_bound(comienzo);
    while (it != treeName.end() && it->first.compare(0, comienzo.size(), comienzo) == 0) {
        resultado.push_back(it->second);
        ++it;
    }
    return resultado;
}

int ControlParques::contarArbolesBarrio(int numBarrio) const {
    int contador = 0;
    for (std::map<std::string, Arbol>::const_iterator it = trees.begin(); it != trees.end(); ++it) {
        if (it->second.getNumBarrio() == numBarrio) {
            contador++;
        }
    }
    return contador;
}

std::vector<Arbol *> ControlParques::buscarArbolPorEspecieYDistrito(const std::string &nbreComun, int numDistrito) {
    std::vector<Arbol*> tArbol = buscarArbolNcomunComienzo(nbreComun);
    std::vector<Arbol*> resultado;
    for (int i = 0; i < tArbol.size(); i++) {
        if (tArbol[i]->getNumDistrito() == numDistrito) {
            resultado.push_back(tArbol[i]);
        }
    }

    return resultado;

}
