//
// Created by a_amo on 22/09/2026.
//

#include "Especie.h"
#include <string>
#include <iostream>

/**
 * @brief: constructor por defecto de la clase Especie
 */
Especie::Especie() :codigoEspecie(" "), nombreComun(""), nombreCientifico(""), tipoPlanta(""){
}

/**
 * @brief: Constructor parametrizado de la clase Especie
 * @param codigo
 * @param nComun
 * @param nCientifico
 * @param tPlanta
 */
Especie::Especie(const std::string& codigo, const std::string& nComun, const std::string& nCientifico, const std::string& tPlanta):codigoEspecie(codigo), nombreComun(nComun),
                                                                                                                                   nombreCientifico(nCientifico), tipoPlanta(tPlanta) {

}

/**
 * @brief: Constructor de copia de la clase Especie
 * @param orig
 */
Especie::Especie(const Especie& orig) {
      this->codigoEspecie = orig.codigoEspecie;
      this->nombreComun = orig.nombreComun;
      this->nombreCientifico = orig.nombreCientifico;
      this->tipoPlanta = orig.tipoPlanta;

}

/**
 * @brief: Metodo para acceder al codigo de una especie
 * @return codigoEspecie
 */
std::string Especie::getcodigoEspecie() const {
      return this->codigoEspecie;
}
/**
 * @brief: Metodo para acceder al nombre comun de una especie
 * @return nombreComun
 */
std::string Especie::getnombre_comun() const {
      return this->nombreComun;
}
/**
 * @brief: Metodo para acceder al nombre cientifico de una especie
 * @return nombreCientifico
 */
std::string Especie::getnombre_cientifico() const {
      return this->nombreCientifico;
}

/**
 * @brief: Metodo para acceder al tipo de planta de una especie
 * @return tipoPlanta
 */
std::string Especie::gettipo_planta() const {
      return this->tipoPlanta;
}

/**
 * @brief: metodo para modificar el codigo de una especie
 * @param c
 */
void Especie::set_codigo_especie(const std::string& c) {
      this->codigoEspecie = c;
}

/**
 * @brief: metodo para modificar el nombre comun de una especie
 * @param n
 */
void Especie::set_nombre_comun(const std::string& n) {
      this->nombreComun = n;
}

/**
 * @brief: metodo para modificar el nombre cientifico de una especie
 * @param n
 */
void Especie::set_nombre_cientifico(const std::string& n) {
      this->nombreCientifico = n;
}

/**
 * @brief: metodo para modificar el tipo de planta de una especie
 * @param t
 */
void Especie::set_tipo_planta(const std::string& t) {
      this->tipoPlanta = t;
}

/**
 * @brief Operador de asignacion de la clase Especie
 * @param origen
 * @return *this
 */
Especie& Especie::operator=(const Especie& origen) {
      if (this != &origen) {
            codigoEspecie = origen.codigoEspecie;
            nombreComun = origen.nombreComun;
            nombreCientifico = origen.nombreCientifico;
            tipoPlanta = origen.tipoPlanta;
      }
      return *this;
}

/**
 * @brief: Operador de comparacion menor que de la clase Especie
 * @param orig
 * @return true si el codigoEspecie del objeto actual es menor que el de orig
 *         false en otro caso
 */
bool Especie::operator<(const Especie& orig) const {
      return codigoEspecie < orig.codigoEspecie;
}


/**
 * @brief: Operador de igualdad de la clase Especie
 * @param orig
 * @return true si el codigoEspecie del objeto actual es igual al de orig
 *         false en otro caso
 */
bool Especie::operator==(const Especie& orig) const {
      return codigoEspecie == orig.codigoEspecie;
}

/**
 * @brief: Funcion que muestra en consola los datos de una especie
 * @param e
 */
void Especie::mostrarEspecie() const {
      std::cout << "Codigo especie: " << this->getcodigoEspecie() << std::endl;
      std::cout << "Nombre comun: " << this->getnombre_comun() << std::endl;
      std::cout << "Nombre cientifico: " << this->getnombre_cientifico() << std::endl;
      std::cout << "Tipo planta: " << this->gettipo_planta() << std::endl;
}

//Metodo para el funcionamiento correcto del enum
TipoPlanta stringToTipoPlanta(const std::string& str) {
      if (str == "ARBUSTO") {
            return TipoPlanta::ARBUSTO;
      }

      if (str == "CONIFERA") {
            return TipoPlanta::CONIFERA;
      }

      if (str == "PALMACEA") {
            return TipoPlanta::PALMACEA;
      }

      if (str == "HERB_PERENNES") {
            return TipoPlanta::HERB_PERENNES;
      }

      if (str == "FRONDOSA") return TipoPlanta::FRONDOSA;

      if (str == "TAPIZANTE/TREPADORA" || str == "TAPIZANTE_TREPADORA") {
            return TipoPlanta::TAPIZANTE_TREPADORA;
      }


      if (str == "CACTACEA/SUCULENTA" || str == "CACTACEA_SUCULENTA") {
            return TipoPlanta::CACTACEA_SUCULENTA;

      }

      if (str == "SUBTROPICAL/TROPICAL" || str == "SUBTROPICAL_TROPICAL") {
            return TipoPlanta::SUBTROPICAL_TROPICAL;
      }


      if (str == "HERB_ANUAL") return TipoPlanta::HERB_ANUAL;
      if (str == "HERB_ANUALES") return TipoPlanta::HERB_ANUALES;

      return TipoPlanta::DESCONOCIDO;
}