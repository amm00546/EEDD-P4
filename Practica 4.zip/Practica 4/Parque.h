//
// Created by a_amo on 07/10/2026.
//

#ifndef PRACTICA_3_PARQUE_H
#define PRACTICA_3_PARQUE_H
#include <string>
#include <vector>
#include <set>
#include <map>
#include "Arbol.h"


class Especie;
class Parque {
private:
    int cod_parque;
    std::string nbre_parque;
    std::vector<Arbol*> contains;

public:
    // Constructor por defecto
    Parque();
    // Constructor parametrizado
    Parque(int codigo, const std::string& nParque);
    // Constructor copia
    Parque(const Parque& orig);

    // Getters
    int get_codigo_parque() const;
    const std::string& get_nombre_parque() const;

    // Setters
    void set_codigo_parque(int c);
    void set_nombre_parque(const std::string& n);

    // Operador de asignación
    Parque& operator=(const Parque& orig);

    // Operadores para la ordenación
    bool operator<(const Parque& orig) const;
    bool operator==(const Parque& orig) const;

    // MÉTODOS EN EL UML
    bool existeNbreCom(const std::string& ncomun) const;
    void insertarArbol(Arbol* arb);
    Arbol* arbolMasAlto() const;
    int contarEspecies() const;
    int contarTipos() const;
    Especie* especieMasComun() const;
    // Metodo auxiliar para consultar los arboles
    const std::vector<Arbol*>& getArboles() const;


};


#endif //PRACTICA_3_PARQUE_H