//
// Created by Pablo on 19/10/2026.
//

#ifndef PRACTICA_3_ARBOL_H
#define PRACTICA_3_ARBOL_H

#include <string>

class Especie;
class Parque;

class Arbol {
private:
    std::string assetnum;
    int numParque;
    int numDistrito;
    std::string nombreDistrito;
    int numBarrio;
    std::string nombreBarrio;
    double x;
    double y;
    float perimetro;
    float altura;

    Especie* especie;
    Parque* isInto;


public:
    Arbol();
    Arbol(const std::string& assetnum, int numParque, int numDistrito,
          const std::string& nombreDistrito, int numBarrio, const std::string& nombreBarrio,
          double x, double y, float perimetro, float altura);
    Arbol(const std::string& assetnum);

    void setEspecie(Especie* e);
    Especie* getEspecie() const;
    std::string getCodEspecie() const;
    std::string getTipoEspecie() const;
    std::string getNbreComun() const;
    std::string getNbreCientifico() const;

    std::string getAssetnum() const;
    int getNumParque() const;
    int getNumDistrito() const;
    std::string getNombreDistrito() const;
    int getNumBarrio() const;
    std::string getNombreBarrio() const;
    double getX() const;
    double getY() const;
    float getAltura() const;
    float getPerimetro() const;

    void setParque(Parque* p);
    Parque* getParque() const;

    bool operator<(const Arbol& otro) const;
    bool operator>(const Arbol& otro) const;
    bool operator==(const Arbol& otro) const;
    bool operator!=(const Arbol& otro) const;
};

#endif //PRACTICA_3_ARBOL_H